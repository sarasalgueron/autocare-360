# Guia 15: ejecutar en PowerShell DESDE la raiz del proyecto Expo (autocare360-mobile).
$ErrorActionPreference = 'Stop'
Write-Host 'Paso 1: revisar dependencias' -ForegroundColor Cyan
npm ls --depth=0
Write-Host 'Paso 2: validar tipos de TypeScript' -ForegroundColor Cyan
npx tsc --noEmit
if ($LASTEXITCODE -ne 0) { throw 'TypeScript no aprobo' }
Write-Host 'Paso 3: ejecutar pruebas de dominio' -ForegroundColor Cyan
npx vitest run
if ($LASTEXITCODE -ne 0) { throw 'Las pruebas no aprobaron' }
Write-Host 'Paso 4: comprobar salud de Expo' -ForegroundColor Cyan
npx expo-doctor
Write-Host 'Recuerda probar el emulador y el backend manualmente.' -ForegroundColor Yellow
