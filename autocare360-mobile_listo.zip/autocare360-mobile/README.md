# autocare360-mobile

App móvil de AutoCare 360: **React Native + TypeScript + Expo (SDK 58) + Expo Router**.
Es el espejo de *ParkFlow360 Mobile* (guías móviles 01–15), adaptado a AutoCare.

## Cómo correrla

```bash
npm install
```
```bash
npx expo start
```
- **Emulador Android** (Android Studio): con Metro abierto, presiona `a`. La app usa `http://10.0.2.2:8080/api`
  (10.0.2.2 es tu PC vista desde el emulador).
- **Teléfono físico**: copia `.env.example` como `.env` y pon la IP de tu PC
  (`EXPO_PUBLIC_API_URL=http://192.168.x.x:8080/api`). PC y teléfono en la misma Wi-Fi.
- **Navegador** (solo para probar rápido, sin emulador): `EXPO_PUBLIC_API_URL=http://localhost:8080/api` y `npx expo start --web`.
  SQLite también funciona en el navegador (gracias a `metro.config.js`); la cámara se prueba en Android.

Usuario de aula: `asesor` / `Clave123!` (lo define el backend en `application.yml`).

## Calidad (Guías 14–15)
```bash
npx tsc --noEmit
```
```bash
npx vitest run
```
```bash
npx expo-doctor
```
O todo junto en PowerShell: `.\scripts\verificar_entrega.ps1`.

APK de prueba (Guía 15, necesita cuenta Expo): `npx eas-cli@latest build -p android --profile preview`.
Antes de compilar pon en `.env` una URL que el teléfono pueda alcanzar (la IP de tu PC o un servidor real):
`10.0.2.2` solo existe dentro del emulador.
Android bloquea `http://` (sin HTTPS) en los APK; por eso `app.json` usa el plugin `expo-build-properties` con
`usesCleartextTraffic: true`. Es solo para el laboratorio: en producción el backend se publica con HTTPS
y esa opción se quita.

## Versión y conflictos (Guías 09, 10 y 12)
- Las pantallas de detalle muestran la `version` del registro; el PUT la reenvía.
- Si otra persona guardó antes, el backend responde **409** y la app lo avisa: no se pisa el cambio ajeno.
- Sin conexión, el cambio queda en `pending_updates` con la versión que se leyó. Al sincronizar, un 409 deja el
  cambio en la cola; desde el editor offline se puede **Descartar cambio pendiente** (trae el dato del servidor).

## Qué hay en cada parte

| Zona | Rutas | Guía | Datos |
|---|---|---|---|
| Local | `/clientes`, `/vehiculos` (+ `nuevo`, `[id]`, `editar/[id]`) | 03–07 | En memoria (reducer). Se pierden al cerrar. |
| Diagnóstico | `/diagnostico` | 08 | `GET /api/health` |
| Login | `/login` | 11 | `POST /api/auth/login` → token en SecureStore |
| Taller (protegido) | `/remoto/clientes/...`, `/remoto/vehiculos/...` | 09–10 | CRUD REST en PostgreSQL |
| Órdenes | `/remoto/ordenes`, `/remoto/ordenes/[id]` | AutoCare (RF-17) | Estado, **aprobar/rechazar estimación**, historial |
| Evidencias | `/remoto/ordenes/evidencia/[id]` | 13 | Cámara / galería → `POST /api/ordenes/{id}/evidencias` |
| Sin conexión | `/remoto/offline` | 12 | SQLite: copia local + cola de cambios |

## Carpetas

```
src/
├── app/          pantallas (cada archivo = una ruta de Expo Router)
├── components/   piezas visuales reutilizables (tarjetas, formularios, Boton, EstadoBadge)
├── domain/       reglas puras sin React ni HTTP (validaciones, tallerRules, estadoOrden)
├── infra/http/   adaptadores REST (apiClient + clientesApi, vehiculosApi, ordenesApi, evidenciasApi)
├── infra/local/  adaptador local de ejemplo (Guía 07)
├── state/        Context + reducer (datos locales) y AuthContext (sesión)
├── offline/      SQLite (Guía 12)
├── security/     tokenStorage con SecureStore (Guía 11)
├── models/ data/ theme/ utils/ hooks/
tests/            pruebas Vitest de las reglas puras (Guía 14)
```
