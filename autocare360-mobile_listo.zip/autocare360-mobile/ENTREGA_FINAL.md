# AutoCare 360 Mobile — Entrega del estudiante (Guía 15)

## Datos obligatorios
- Nombre del estudiante:
- Proyecto: AutoCare 360 (PA-02). Relación 1:N: Cliente (1) — Vehículo (N); además Vehículo (1) — OrdenServicio (N).
- Repositorio y commit de entrega:
- Versiones: Expo SDK 58, React Native 0.88, Node 24 LTS.
- APK de distribución de prueba:
- Backend y PostgreSQL disponibles mediante: `autocare-backend` (Spring Boot 4) + PostgreSQL local o `docker compose`.

## Evidencias mínimas
- Pantallas locales de Cliente y Vehículo (CRUD en memoria).
- CRUD REST de Cliente y Vehículo con relación 1:N comprobada en PostgreSQL.
- Validación: placa duplicada (409) y eliminación de cliente con vehículos (409).
- Captura de GET exitoso y de errores 400, 401, 404 o 409.
- Login y logout con token en SecureStore.
- Aprobación de estimación desde el móvil (RF-17) y su registro en el historial.
- Evidencia con foto y descripción (RN-08).
- Copia sin conexión con SQLite y sincronización manual.
- `npx vitest run` aprobado y `npx tsc --noEmit` sin errores.
- APK instalado y probado.

## Defensa individual
Explica con tus palabras:
- El flujo interfaz → `apiClient` → Controller → caso de uso → puerto → JPA → PostgreSQL y de regreso.
- Por qué el móvil nunca se conecta directo a la base de datos.
- Qué vive en memoria (reducer), qué en SQLite y qué en el servidor.
- Por qué ocultar botones no es seguridad y cómo el backend exige el token.
- Por qué el móvil solo muestra las transiciones que el backend envía en `transicionesPermitidas`.
