@echo off
echo Instalando las librerias de la app (solo la primera vez)...
call npm install
pause
