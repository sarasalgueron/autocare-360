# Control de calidad — AutoCare 360 Mobile (Guía 14)

## Niveles de prueba
- **Unitario**: Vitest sobre reglas puras (`tests/`), sin red ni Android.
- **Integración**: la app llama al Spring Boot real y se verifica status y DTO.
- **End-to-end manual**: recorrer UI → REST → PostgreSQL con evidencias (capturas, consultas SQL).
- **Seguridad**: sin token o con token falso → 401 (backend con `AUTOCARE_AUTH_REQUIRED=true`).

## Secuencia mínima reproducible
1. `npx tsc --noEmit` sin errores.
2. `npx vitest run` → 31 pruebas aprobadas.
3. `npx expo-doctor` → 20/20 checks.
4. Arrancar PostgreSQL y el backend `autocare-backend`.
5. Abrir el emulador y `npx expo start --clear`, tecla `a`.
6. Diagnóstico: `GET /health` → `HTTP 200 - UP - autocare`.
7. Login con contraseña incorrecta → "Usuario o contrasena incorrectos"; con `Clave123!` → entra a /remoto.
8. Crear vehículo remoto con placa existente → mensaje 409; con placa nueva → aparece en la lista y en PostgreSQL.
9. Orden en DIAGNOSTICO → "Avance" → ESPERA_APROBACION → "Aprobar estimación" → EN_TRABAJO; revisar historial.
10. Rechazar sin motivo → la app lo pide; con motivo → vuelve a DIAGNOSTICO.
11. Agregar evidencia sin descripción → bloqueado (RN-08); con descripción → aparece la foto en la orden.
12. Apagar el backend → mensaje de conexión (no "no existe").
13. Sin conexión: descargar clientes, editar uno, sincronizar al volver la red.
13b. Conflicto: editar un cliente sin red, cambiarlo desde la web, sincronizar → 409 y el cambio queda en la cola;
     "Descartar cambio pendiente" lo resuelve.
13c. Editar el mismo cliente remoto en dos lugares con la misma versión → el segundo recibe 409.
14. El permiso de cámara se pide solo al tocar "Tomar fotografía".

## Resultado de esta versión (verificado al construirla)
| Prueba | Resultado |
|---|---|
| tsc / vitest | OK / 31 de 31 |
| expo-doctor | 17 de 20 en esta máquina: las 3 que faltan necesitan internet hacia los servidores de Expo; las versiones coinciden con el SDK 58 |
| Bundle Android (`npx expo export --platform android`) y `expo prebuild` (manifest con cleartext) | OK |
| 6, 7, 8, 9, 13, 13b, 13c, login y 401 con token falso (en navegador, contra backend + PostgreSQL) | OK (ver `docs/PRUEBAS_Y_EVIDENCIAS.md`) |
| 11 y 14 (cámara, galería) y APK instalado | Pendiente de probar en emulador o teléfono Android |

Nunca subir tokens ni credenciales reales a las evidencias.
