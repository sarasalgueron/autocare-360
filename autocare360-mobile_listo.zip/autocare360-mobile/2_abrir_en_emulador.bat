@echo off
echo Antes: prende el backend en IntelliJ y abre un emulador en Android Studio.
echo Cuando aparezca el menu de Expo, aprieta la tecla a
call npx expo start
pause
