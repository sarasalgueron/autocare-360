@echo off
echo Antes: prende el backend en IntelliJ.
echo La app se abre en Chrome (la camara no funciona en Chrome).
set EXPO_PUBLIC_API_URL=http://localhost:8080/api
call npx expo start --web
pause
