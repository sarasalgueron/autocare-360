import { Alert, Platform } from 'react-native';

/**
 * Alert.alert es el dialogo nativo de Android. En el navegador (expo start --web) Alert no
 * muestra nada, por eso ahi usamos window.confirm / window.alert. Las pantallas solo llaman
 * a estas funciones y no se preocupan de la plataforma.
 */
export function confirmar(titulo: string, mensaje: string, textoConfirmar = 'Eliminar'): Promise<boolean> {
  if (Platform.OS === 'web') {
    return Promise.resolve(globalThis.confirm?.(`${titulo}\n\n${mensaje}`) ?? false);
  }
  return new Promise((resolve) => {
    Alert.alert(titulo, mensaje, [
      { text: 'Cancelar', style: 'cancel', onPress: () => resolve(false) },
      { text: textoConfirmar, style: 'destructive', onPress: () => resolve(true) },
    ]);
  });
}

export function avisar(titulo: string, mensaje: string): void {
  if (Platform.OS === 'web') {
    globalThis.alert?.(`${titulo}\n\n${mensaje}`);
    return;
  }
  Alert.alert(titulo, mensaje);
}

export function mensajeDe(error: unknown, porDefecto = 'Error inesperado'): string {
  return error instanceof Error ? error.message : porDefecto;
}
