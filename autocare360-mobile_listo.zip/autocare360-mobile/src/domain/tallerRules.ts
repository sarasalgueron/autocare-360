import type { Cliente, Vehiculo } from '../models/taller';

/** Dominio (Guia 07): reglas independientes de React, de las pantallas y de HTTP. */

export function puedeEliminarCliente(clienteId: number, vehiculos: readonly Vehiculo[]): boolean {
  return !vehiculos.some((v) => v.clienteId === clienteId);
}

export function placaOcupada(placa: string, vehiculos: readonly Vehiculo[], exceptoId?: number): boolean {
  return vehiculos.some((v) => v.placa === placa && v.id !== exceptoId);
}

export function clienteExiste(id: number, clientes: readonly Cliente[]): boolean {
  return clientes.some((c) => c.id === id);
}

/** RN-01: un vehiculo solo puede asignarse a un propietario activo. */
export function clienteActivo(id: number, clientes: readonly Cliente[]): boolean {
  return clientes.some((c) => c.id === id && c.activo);
}

export function vehiculosDe(clienteId: number, vehiculos: readonly Vehiculo[]): Vehiculo[] {
  return vehiculos.filter((v) => v.clienteId === clienteId);
}

/** Propietarios que se pueden elegir: activos, y ademas el actual si se esta editando. */
export function idsPropietariosValidos(
  clientes: readonly { id: number; activo: boolean }[],
  propietarioActual?: number,
): number[] {
  return clientes.filter((c) => c.activo || c.id === propietarioActual).map((c) => c.id);
}
