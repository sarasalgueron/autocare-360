/** RN-02: estados de la orden (iguales al enum EstadoOrden de Java y al CHECK de PostgreSQL). */
export type EstadoOrden =
  | 'ABIERTA'
  | 'DIAGNOSTICO'
  | 'ESPERA_APROBACION'
  | 'EN_TRABAJO'
  | 'LISTA_ENTREGA'
  | 'ENTREGADA'
  | 'CANCELADA';

export const ESTADO_LABEL: Record<EstadoOrden, string> = {
  ABIERTA: 'Abierta',
  DIAGNOSTICO: 'Diagnostico',
  ESPERA_APROBACION: 'Espera tu aprobacion',
  EN_TRABAJO: 'En trabajo',
  LISTA_ENTREGA: 'Lista para entrega',
  ENTREGADA: 'Entregada',
  CANCELADA: 'Cancelada',
};

export function esOrdenActiva(estado: EstadoOrden): boolean {
  return estado !== 'ENTREGADA' && estado !== 'CANCELADA';
}

export type AccionMovil = {
  destino: EstadoOrden;
  etiqueta: string;
  tipo: 'aprobar' | 'rechazar' | 'avance';
};

/**
 * Que puede hacer la app movil con una orden (la app NO es una copia de la web).
 * - Cliente (RF-17): aprobar o rechazar la estimacion cuando la orden espera su aprobacion.
 * - Tecnico: registrar avance (pasar al siguiente estado de trabajo).
 * Entregar y cancelar quedan en la web del asesor. Solo se ofrecen destinos que el BACKEND
 * declaro validos en transicionesPermitidas: la regla real vive en Spring Boot.
 */
export function accionesMovil(estado: EstadoOrden, transicionesPermitidas: readonly EstadoOrden[]): AccionMovil[] {
  if (estado === 'ESPERA_APROBACION') {
    const acciones: AccionMovil[] = [];
    if (transicionesPermitidas.includes('EN_TRABAJO')) {
      acciones.push({ destino: 'EN_TRABAJO', etiqueta: 'Aprobar estimacion', tipo: 'aprobar' });
    }
    if (transicionesPermitidas.includes('DIAGNOSTICO')) {
      acciones.push({ destino: 'DIAGNOSTICO', etiqueta: 'Rechazar estimacion', tipo: 'rechazar' });
    }
    return acciones;
  }
  return transicionesPermitidas
    .filter((destino) => destino !== 'ENTREGADA' && destino !== 'CANCELADA')
    .map((destino) => ({ destino, etiqueta: `Avance: pasar a ${ESTADO_LABEL[destino]}`, tipo: 'avance' }));
}
