import { TIPOS_VEHICULO, type TipoVehiculo } from '../models/taller';

/** Reglas PURAS (Guia 04): se prueban con Vitest sin Android ni base de datos. */

// ---------------- Cliente ----------------
export type ClienteFormValue = {
  documento: string;
  nombreCompleto: string;
  email: string;
  telefono: string;
  activo: boolean;
};
export type ClienteFormErrores = Partial<Record<'documento' | 'nombreCompleto' | 'email' | 'telefono', string>>;

export function validarCliente(entrada: ClienteFormValue): ClienteFormErrores {
  const errores: ClienteFormErrores = {};
  if (entrada.documento.trim().length < 5) errores.documento = 'El documento debe tener al menos 5 caracteres.';
  if (entrada.nombreCompleto.trim().length < 3) errores.nombreCompleto = 'Minimo 3 caracteres.';
  if (entrada.email.trim() && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(entrada.email.trim())) {
    errores.email = 'Escribe un correo con formato nombre@dominio.com.';
  }
  if (entrada.telefono.trim() && !/^[0-9+\- ]{7,20}$/.test(entrada.telefono.trim())) {
    errores.telefono = 'El telefono debe tener entre 7 y 20 digitos.';
  }
  return errores;
}

// ---------------- Vehiculo ----------------
/** anio y kilometraje son texto porque asi los entrega un TextInput; se convierten tras validar. */
export type VehiculoFormValue = {
  clienteId: number | null;
  placa: string;
  marca: string;
  modelo: string;
  anio: string;
  tipo: TipoVehiculo;
  kilometraje: string;
};
export type VehiculoFormErrores = Partial<Record<keyof VehiculoFormValue, string>>;

export const normalizarPlaca = (placa: string): string => placa.trim().toUpperCase();

/**
 * @param idsClientesValidos ids de propietarios que se pueden elegir (RN-01: solo activos,
 *        excepto el propietario actual al editar).
 */
export function validarVehiculo(entrada: VehiculoFormValue, idsClientesValidos: readonly number[]): VehiculoFormErrores {
  const errores: VehiculoFormErrores = {};
  const anioMaximo = new Date().getFullYear() + 1;
  if (entrada.clienteId === null || !idsClientesValidos.includes(entrada.clienteId)) {
    errores.clienteId = 'Selecciona un propietario activo de la lista.';
  }
  if (!/^[A-Z0-9-]{5,15}$/.test(normalizarPlaca(entrada.placa))) {
    errores.placa = 'Solo letras, numeros y guion. Ejemplo: 4567-ABC.';
  }
  if (entrada.marca.trim().length < 2) errores.marca = 'La marca debe contener al menos 2 caracteres.';
  if (entrada.modelo.trim().length < 2) errores.modelo = 'El modelo debe contener al menos 2 caracteres.';
  const anio = Number(entrada.anio);
  if (!Number.isInteger(anio) || anio < 1950 || anio > anioMaximo) {
    errores.anio = `Ingresa un anio entre 1950 y ${anioMaximo}.`;
  }
  const km = Number(entrada.kilometraje);
  if (entrada.kilometraje.trim() === '' || !Number.isInteger(km) || km < 0) {
    errores.kilometraje = 'El kilometraje debe ser un entero mayor o igual a 0.';
  }
  if (!TIPOS_VEHICULO.includes(entrada.tipo)) errores.tipo = 'Selecciona un tipo valido.';
  return errores;
}
