import type { Cliente, Vehiculo } from '../models/taller';

/** Contrato (Guia 07): NO depende de fetch, Expo, PostgreSQL ni Android. */
export interface TallerRepository {
  listarClientes(): Promise<Cliente[]>;
  buscarCliente(id: number): Promise<Cliente | null>;
  listarVehiculos(clienteId?: number): Promise<Vehiculo[]>;
}
