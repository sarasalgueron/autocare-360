// Un modelo describe la FORMA de los datos: no guarda registros reales.

export const TIPOS_VEHICULO = ['AUTO', 'CAMIONETA', 'SUV', 'MOTO', 'VAN', 'OTRO'] as const;
export type TipoVehiculo = (typeof TIPOS_VEHICULO)[number];

export type Cliente = Readonly<{
  id: number;
  documento: string;
  nombreCompleto: string;
  email: string;
  telefono: string;
  activo: boolean;
}>;

/** Relacion Cliente (1) — Vehiculo (N): cada vehiculo guarda el id de su propietario. */
export type Vehiculo = Readonly<{
  id: number;
  clienteId: number;
  placa: string;
  marca: string;
  modelo: string;
  anio: number;
  tipo: TipoVehiculo;
  kilometraje: number;
}>;

/** Guia 02: secciones de la pantalla de practica. Solo dos valores posibles (union de literales). */
export type Seccion = 'clientes' | 'vehiculos';
