import * as SQLite from 'expo-sqlite';
import type { ClienteFormValue } from '../domain/validaciones';
import { clientesApi, type ClienteDto } from '../infra/http/clientesApi';

/**
 * Guia 12: SQLite dentro del telefono.
 * - cached_clients: copia de los clientes para CONSULTAR sin conexion.
 * - pending_updates: cola de cambios hechos sin conexion que se envian MANUALMENTE.
 * Cada fila guarda la "version" que tenia el cliente cuando se descargo. Al sincronizar se envia
 * esa version: si alguien cambio el cliente en el servidor mientras tanto, el backend responde 409
 * y el cambio QUEDA en la cola (un conflicto exige que una persona decida, no se pisa en silencio).
 */
export type ClienteCache = {
  id: number;
  documento: string;
  nombreCompleto: string;
  email: string;
  telefono: string;
  activo: boolean;
  version: number;
};

type Fila = {
  id: number;
  documento: string;
  nombre_completo: string;
  email: string;
  telefono: string;
  activo: number;
  version: number;
};

/** Version del ESQUEMA de esta base local (PRAGMA user_version). Sube cuando cambian las tablas. */
const VERSION_ESQUEMA = 2;

let dbPromise: ReturnType<typeof SQLite.openDatabaseAsync> | null = null;
let iniciada: Promise<void> | null = null;

async function database() {
  if (!dbPromise) dbPromise = SQLite.openDatabaseAsync('autocare_offline.db');
  return dbPromise;
}

function mapear(fila: Fila): ClienteCache {
  return {
    id: fila.id,
    documento: fila.documento,
    nombreCompleto: fila.nombre_completo,
    email: fila.email,
    telefono: fila.telefono,
    activo: fila.activo === 1,
    version: fila.version,
  };
}

/** Si un telefono ya tenia la base de una version anterior (sin columna "version"), se la agrega. */
async function agregarColumnaVersionSiFalta(db: SQLite.SQLiteDatabase, tabla: 'cached_clients' | 'pending_updates') {
  const columnas = await db.getAllAsync<{ name: string }>(`PRAGMA table_info(${tabla})`);
  if (!columnas.some((c) => c.name === 'version')) {
    await db.execAsync(`ALTER TABLE ${tabla} ADD COLUMN version INTEGER NOT NULL DEFAULT 0`);
  }
}

/**
 * Crea las tablas una sola vez por ejecucion de la app.
 * execAsync solo con SQL constante. Los VALORES siempre entran por parametros (?) -> sin inyeccion SQL.
 */
export function iniciarCache(): Promise<void> {
  if (!iniciada) {
    iniciada = (async () => {
      const db = await database();
      await db.execAsync(`
        CREATE TABLE IF NOT EXISTS cached_clients (
          id INTEGER PRIMARY KEY, documento TEXT NOT NULL, nombre_completo TEXT NOT NULL,
          email TEXT NOT NULL, telefono TEXT NOT NULL, activo INTEGER NOT NULL,
          version INTEGER NOT NULL DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS pending_updates (
          id INTEGER PRIMARY KEY, documento TEXT NOT NULL, nombre_completo TEXT NOT NULL,
          email TEXT NOT NULL, telefono TEXT NOT NULL, activo INTEGER NOT NULL,
          version INTEGER NOT NULL DEFAULT 0
        );
      `);
      const fila = await db.getFirstAsync<{ user_version: number }>('PRAGMA user_version');
      if ((fila?.user_version ?? 0) < VERSION_ESQUEMA) {
        await agregarColumnaVersionSiFalta(db, 'cached_clients');
        await agregarColumnaVersionSiFalta(db, 'pending_updates');
        await db.execAsync(`PRAGMA user_version = ${VERSION_ESQUEMA}`);
      }
    })().catch((error: unknown) => {
      iniciada = null; // si fallo, el proximo intento vuelve a probar
      throw error;
    });
  }
  return iniciada;
}

async function guardarEnTabla(tabla: 'cached_clients' | 'pending_updates', c: ClienteCache): Promise<void> {
  const db = await database();
  await db.runAsync(
    `INSERT OR REPLACE INTO ${tabla}(id, documento, nombre_completo, email, telefono, activo, version) VALUES (?,?,?,?,?,?,?)`,
    c.id, c.documento, c.nombreCompleto, c.email, c.telefono, c.activo ? 1 : 0, c.version,
  );
}

function desdeDto(dto: ClienteDto): ClienteCache {
  return {
    id: dto.id,
    documento: dto.documento,
    nombreCompleto: dto.nombreCompleto,
    email: dto.email ?? '',
    telefono: dto.telefono ?? '',
    activo: dto.activo,
    version: dto.version,
  };
}

export async function listarCache(): Promise<ClienteCache[]> {
  await iniciarCache();
  const db = await database();
  const filas = await db.getAllAsync<Fila>('SELECT * FROM cached_clients ORDER BY nombre_completo');
  return filas.map(mapear);
}

/** Con conexion: trae los clientes del backend (con su version) y los guarda en SQLite. */
export async function descargarClientes(): Promise<number> {
  const remotos = await clientesApi.listar();
  await iniciarCache();
  for (const c of remotos) {
    await guardarEnTabla('cached_clients', desdeDto(c));
  }
  return remotos.length;
}

/**
 * Sin conexion: el cambio queda en la cola y tambien se refleja en la copia local.
 * Conserva la version que se LEYO (no la incrementa: eso solo lo hace el servidor).
 */
export async function dejarPendiente(cliente: ClienteCache): Promise<void> {
  await iniciarCache();
  await guardarEnTabla('pending_updates', cliente);
  await guardarEnTabla('cached_clients', cliente);
}

export async function contarPendientes(): Promise<number> {
  await iniciarCache();
  const db = await database();
  const fila = await db.getFirstAsync<{ total: number }>('SELECT COUNT(*) AS total FROM pending_updates');
  return fila?.total ?? 0;
}

/** true si ese cliente tiene un cambio esperando sincronizacion. */
export async function tienePendiente(id: number): Promise<boolean> {
  await iniciarCache();
  const db = await database();
  const fila = await db.getFirstAsync<{ total: number }>('SELECT COUNT(*) AS total FROM pending_updates WHERE id = ?', id);
  return (fila?.total ?? 0) > 0;
}

/**
 * Resolver un conflicto (409) a mano: se descarta el cambio local y la copia vuelve a la del servidor.
 * Requiere conexion (hace GET /clientes/{id}).
 */
export async function descartarPendiente(id: number): Promise<void> {
  const remoto = await clientesApi.obtener(id);
  await iniciarCache();
  const db = await database();
  await db.runAsync('DELETE FROM pending_updates WHERE id = ?', id);
  await guardarEnTabla('cached_clients', desdeDto(remoto));
}

/**
 * Envia cada cambio pendiente con PUT + version. Si el backend lo rechaza (400/404/409) queda en la cola:
 * un 409 significa que otra persona cambio el cliente en el servidor despues de la descarga.
 */
export async function sincronizarPendientes(): Promise<{ correctos: number; fallidos: string[] }> {
  await iniciarCache();
  const db = await database();
  const pendientes = (await db.getAllAsync<Fila>('SELECT * FROM pending_updates ORDER BY id')).map(mapear);
  let correctos = 0;
  const fallidos: string[] = [];
  for (const p of pendientes) {
    const valor: ClienteFormValue = {
      documento: p.documento,
      nombreCompleto: p.nombreCompleto,
      email: p.email,
      telefono: p.telefono,
      activo: p.activo,
    };
    try {
      const actualizado = await clientesApi.editar(p.id, valor, p.version);
      await db.runAsync('DELETE FROM pending_updates WHERE id = ?', p.id);
      await guardarEnTabla('cached_clients', desdeDto(actualizado)); // ya con la version NUEVA
      correctos++;
    } catch (e) {
      // NO se elimina el cambio rechazado: un 409 exige que una persona decida (descartar o volver a editar).
      fallidos.push(`Cliente ${p.id}: ${e instanceof Error ? e.message : 'Error'}`);
    }
  }
  return { correctos, fallidos };
}
