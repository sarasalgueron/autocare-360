import { useMemo } from 'react';
import { useTaller } from '../state/TallerContext';

/** Hook de presentacion (Guia 07): calcula metricas; no cambia datos ni consulta la red. */
export function useTallerStats() {
  const { clientes, vehiculos } = useTaller();
  return useMemo(
    () => ({
      clientes: clientes.length,
      vehiculos: vehiculos.length,
      sinVehiculos: clientes.filter((c) => !vehiculos.some((v) => v.clienteId === c.id)).length,
    }),
    [clientes, vehiculos],
  );
}
