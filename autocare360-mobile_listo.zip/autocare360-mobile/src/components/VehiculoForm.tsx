import { useState } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { idsPropietariosValidos } from '../domain/tallerRules';
import { validarVehiculo, type VehiculoFormErrores, type VehiculoFormValue } from '../domain/validaciones';
import { TIPOS_VEHICULO } from '../models/taller';
import { PALETTE } from '../theme/palette';
import { Boton } from './Boton';

export type OpcionPropietario = { id: number; nombre: string; activo: boolean };

type Props = {
  propietarios: readonly OpcionPropietario[];
  valorInicial?: VehiculoFormValue;
  textoBoton: string;
  alGuardar: (valor: VehiculoFormValue & { clienteId: number }) => void;
  guardando?: boolean;
};

const VACIO: VehiculoFormValue = { clienteId: null, placa: '', marca: '', modelo: '', anio: '', tipo: 'AUTO', kilometraje: '' };

/**
 * Formulario de vehiculo. El usuario ve el NOMBRE del propietario, pero el estado guarda su ID
 * (asi se representa la relacion 1:N). Solo se ofrecen propietarios activos (RN-01),
 * excepto el propietario actual cuando se edita.
 */
export function VehiculoForm({ propietarios, valorInicial = VACIO, textoBoton, alGuardar, guardando = false }: Props) {
  const [form, setForm] = useState<VehiculoFormValue>(valorInicial);
  const [errores, setErrores] = useState<VehiculoFormErrores>({});
  const propietarioActual = valorInicial.clienteId ?? undefined;
  const opciones = propietarios.filter((p) => p.activo || p.id === propietarioActual);

  function cambiar<K extends keyof VehiculoFormValue>(clave: K, valor: VehiculoFormValue[K]) {
    setForm((actual) => ({ ...actual, [clave]: valor }));
  }

  function guardar() {
    const encontrados = validarVehiculo(form, idsPropietariosValidos(propietarios, propietarioActual));
    setErrores(encontrados);
    if (Object.keys(encontrados).length !== 0 || form.clienteId === null) return;
    alGuardar({ ...form, clienteId: form.clienteId });
  }

  return (
    <ScrollView contentContainerStyle={styles.contenido} keyboardShouldPersistTaps="handled">
      <Text style={styles.etiqueta}>PROPIETARIO (OBLIGATORIO)</Text>
      {opciones.map((p) => (
        <Pressable key={p.id} accessibilityRole="radio" accessibilityState={{ selected: form.clienteId === p.id }}
          onPress={() => cambiar('clienteId', p.id)} style={[styles.opcion, form.clienteId === p.id && styles.seleccionado]}>
          <Text style={styles.texto}>
            {form.clienteId === p.id ? '◉ ' : '○ '}
            {p.nombre}
            {p.activo ? '' : ' (inactivo)'}
          </Text>
        </Pressable>
      ))}
      {errores.clienteId && <Text accessibilityRole="alert" style={styles.error}>{errores.clienteId}</Text>}

      <Text style={styles.etiqueta}>PLACA</Text>
      <TextInput accessibilityLabel="Placa" placeholder="4567-ABC" autoCapitalize="characters" value={form.placa}
        onChangeText={(v) => cambiar('placa', v)} maxLength={15} style={styles.entrada} />
      {errores.placa && <Text style={styles.error}>{errores.placa}</Text>}

      <Text style={styles.etiqueta}>MARCA</Text>
      <TextInput accessibilityLabel="Marca" placeholder="Toyota" value={form.marca} onChangeText={(v) => cambiar('marca', v)} style={styles.entrada} />
      {errores.marca && <Text style={styles.error}>{errores.marca}</Text>}

      <Text style={styles.etiqueta}>MODELO</Text>
      <TextInput accessibilityLabel="Modelo" placeholder="Corolla" value={form.modelo} onChangeText={(v) => cambiar('modelo', v)} style={styles.entrada} />
      {errores.modelo && <Text style={styles.error}>{errores.modelo}</Text>}

      <View style={styles.dosColumnas}>
        <View style={styles.columna}>
          <Text style={styles.etiqueta}>ANIO</Text>
          <TextInput accessibilityLabel="Anio" placeholder="2022" keyboardType="number-pad" value={form.anio}
            onChangeText={(v) => cambiar('anio', v)} style={styles.entrada} />
          {errores.anio && <Text style={styles.error}>{errores.anio}</Text>}
        </View>
        <View style={styles.columna}>
          <Text style={styles.etiqueta}>KILOMETRAJE</Text>
          <TextInput accessibilityLabel="Kilometraje" placeholder="35000" keyboardType="number-pad" value={form.kilometraje}
            onChangeText={(v) => cambiar('kilometraje', v)} style={styles.entrada} />
          {errores.kilometraje && <Text style={styles.error}>{errores.kilometraje}</Text>}
        </View>
      </View>

      <Text style={styles.etiqueta}>TIPO</Text>
      <View style={styles.chips}>
        {TIPOS_VEHICULO.map((tipo) => (
          <Pressable key={tipo} accessibilityRole="radio" accessibilityState={{ selected: form.tipo === tipo }}
            onPress={() => cambiar('tipo', tipo)} style={[styles.chip, form.tipo === tipo && styles.seleccionado]}>
            <Text style={styles.texto}>{tipo}</Text>
          </Pressable>
        ))}
      </View>

      <Boton texto={textoBoton} alPresionar={guardar} cargando={guardando} />
      <Text style={styles.ayuda}>Validar en el movil no reemplaza validar en Spring Boot (placa unica, RN-01).</Text>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  contenido: { padding: 18, paddingBottom: 55 },
  etiqueta: { fontWeight: '800', color: PALETTE.principal, marginTop: 16, marginBottom: 8 },
  opcion: { padding: 12, borderRadius: 10, borderWidth: 1, borderColor: PALETTE.borde, marginBottom: 7, backgroundColor: '#fff' },
  seleccionado: { backgroundColor: PALETTE.acentoClaro, borderColor: PALETTE.acento },
  texto: { color: PALETTE.principal },
  entrada: { backgroundColor: '#fff', padding: 13, borderWidth: 1, borderColor: PALETTE.borde, borderRadius: 10, color: PALETTE.principal },
  error: { color: PALETTE.peligro, marginTop: 5, fontSize: 13 },
  dosColumnas: { flexDirection: 'row', gap: 12 },
  columna: { flex: 1 },
  chips: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  chip: { paddingVertical: 9, paddingHorizontal: 13, borderRadius: 99, borderWidth: 1, borderColor: PALETTE.borde, backgroundColor: '#fff' },
  ayuda: { marginTop: 15, color: PALETTE.secundario, lineHeight: 21 },
});
