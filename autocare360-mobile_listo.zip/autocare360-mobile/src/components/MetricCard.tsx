import { StyleSheet, Text, View } from 'react-native';
import { PALETTE } from '../theme/palette';

export function MetricCard({ etiqueta, valor }: { etiqueta: string; valor: number }) {
  return (
    <View style={styles.tarjeta}>
      <Text style={styles.valor}>{valor}</Text>
      <Text style={styles.etiqueta}>{etiqueta}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  tarjeta: {
    flex: 1,
    minWidth: 100,
    backgroundColor: PALETTE.superficie,
    borderColor: PALETTE.borde,
    borderWidth: 1,
    borderRadius: 16,
    padding: 14,
  },
  valor: { fontSize: 26, fontWeight: '800', color: PALETTE.principal },
  etiqueta: { color: PALETTE.secundario, marginTop: 4, fontSize: 13 },
});
