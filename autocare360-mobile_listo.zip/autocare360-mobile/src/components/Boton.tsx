import { ActivityIndicator, Pressable, StyleSheet, Text } from 'react-native';
import { PALETTE } from '../theme/palette';

type Props = {
  texto: string;
  alPresionar: () => void;
  variante?: 'primario' | 'secundario' | 'peligro' | 'exito';
  cargando?: boolean;
  deshabilitado?: boolean;
};

/** Boton comun: mismo aspecto en toda la app y se bloquea mientras "cargando" (evita doble envio). */
export function Boton({ texto, alPresionar, variante = 'primario', cargando = false, deshabilitado = false }: Props) {
  const bloqueado = deshabilitado || cargando;
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityState={{ disabled: bloqueado, busy: cargando }}
      onPress={alPresionar}
      disabled={bloqueado}
      style={({ pressed }) => [styles.base, styles[variante], (pressed || bloqueado) && styles.atenuado]}
    >
      {cargando ? (
        <ActivityIndicator color={variante === 'secundario' ? PALETTE.principal : '#fff'} />
      ) : (
        <Text style={[styles.texto, variante === 'secundario' && styles.textoSecundario]}>{texto}</Text>
      )}
    </Pressable>
  );
}

const styles = StyleSheet.create({
  base: { padding: 15, borderRadius: 12, marginTop: 12, minHeight: 50, justifyContent: 'center' },
  primario: { backgroundColor: PALETTE.acento },
  secundario: { backgroundColor: PALETTE.acentoClaro },
  peligro: { backgroundColor: PALETTE.peligro },
  exito: { backgroundColor: PALETTE.exito },
  atenuado: { opacity: 0.6 },
  texto: { color: '#fff', textAlign: 'center', fontWeight: '800' },
  textoSecundario: { color: PALETTE.principal },
});
