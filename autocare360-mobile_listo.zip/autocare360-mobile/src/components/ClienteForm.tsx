import { useState } from 'react';
import { ScrollView, StyleSheet, Switch, Text, TextInput, View } from 'react-native';
import { validarCliente, type ClienteFormErrores, type ClienteFormValue } from '../domain/validaciones';
import { PALETTE } from '../theme/palette';
import { Boton } from './Boton';

type Props = {
  valorInicial?: ClienteFormValue;
  textoBoton: string;
  alGuardar: (valor: ClienteFormValue) => void;
  mostrarActivo?: boolean; // al crear, el cliente siempre nace activo
  guardando?: boolean;
};

const VACIO: ClienteFormValue = { documento: '', nombreCompleto: '', email: '', telefono: '', activo: true };

/**
 * Formulario CONTROLADO (Guia 04): cada TextInput muestra lo que hay en el estado "valor".
 * El componente valida, pero NO decide si se guarda en memoria o en PostgreSQL: eso lo decide el padre.
 */
export function ClienteForm({ valorInicial = VACIO, textoBoton, alGuardar, mostrarActivo = true, guardando = false }: Props) {
  const [valor, setValor] = useState<ClienteFormValue>(valorInicial);
  const [errores, setErrores] = useState<ClienteFormErrores>({});

  function cambiar<K extends keyof ClienteFormValue>(clave: K, nuevo: ClienteFormValue[K]) {
    setValor((actual) => ({ ...actual, [clave]: nuevo }));
  }

  function guardar() {
    const encontrados = validarCliente(valor);
    setErrores(encontrados);
    if (Object.keys(encontrados).length > 0) return;
    alGuardar({
      ...valor,
      documento: valor.documento.trim(),
      nombreCompleto: valor.nombreCompleto.trim(),
      email: valor.email.trim().toLowerCase(),
      telefono: valor.telefono.trim(),
    });
  }

  return (
    <ScrollView contentContainerStyle={styles.contenido} keyboardShouldPersistTaps="handled">
      <Text style={styles.label}>DOCUMENTO (CI/NIT)</Text>
      <TextInput accessibilityLabel="Documento" value={valor.documento} onChangeText={(t) => cambiar('documento', t)}
        keyboardType="number-pad" placeholder="7845123" style={styles.input} />
      {errores.documento && <Text style={styles.error}>{errores.documento}</Text>}

      <Text style={styles.label}>NOMBRE COMPLETO</Text>
      <TextInput accessibilityLabel="Nombre completo" value={valor.nombreCompleto}
        onChangeText={(t) => cambiar('nombreCompleto', t)} placeholder="Ej.: Rosa Lopez" style={styles.input} />
      {errores.nombreCompleto && <Text style={styles.error}>{errores.nombreCompleto}</Text>}

      <Text style={styles.label}>CORREO (OPCIONAL)</Text>
      <TextInput accessibilityLabel="Correo" value={valor.email} onChangeText={(t) => cambiar('email', t)}
        autoCapitalize="none" keyboardType="email-address" placeholder="rosa@ejemplo.com" style={styles.input} />
      {errores.email && <Text style={styles.error}>{errores.email}</Text>}

      <Text style={styles.label}>TELEFONO (OPCIONAL)</Text>
      <TextInput accessibilityLabel="Telefono" value={valor.telefono} onChangeText={(t) => cambiar('telefono', t)}
        keyboardType="phone-pad" placeholder="70000000" style={styles.input} />
      {errores.telefono && <Text style={styles.error}>{errores.telefono}</Text>}

      {mostrarActivo && (
        <View style={styles.fila}>
          <Text style={styles.label}>CLIENTE ACTIVO</Text>
          <Switch accessibilityLabel="Cliente activo" value={valor.activo} onValueChange={(v) => cambiar('activo', v)} />
        </View>
      )}

      <Boton texto={textoBoton} alPresionar={guardar} cargando={guardando} />
      <Text style={styles.ayuda}>Validar en el movil no reemplaza la validacion de Spring Boot.</Text>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  contenido: { padding: 18, paddingBottom: 50 },
  label: { marginTop: 18, marginBottom: 9, color: PALETTE.principal, fontWeight: '800' },
  input: { borderWidth: 1, borderColor: PALETTE.borde, backgroundColor: '#fff', borderRadius: 10, padding: 13 },
  error: { marginTop: 6, color: PALETTE.peligro },
  fila: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  ayuda: { marginTop: 15, color: PALETTE.secundario, lineHeight: 21 },
});
