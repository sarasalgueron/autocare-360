import { StyleSheet, Text } from 'react-native';
import { ESTADO_LABEL, type EstadoOrden } from '../domain/estadoOrden';

const COLORES: Record<EstadoOrden, { fondo: string; texto: string }> = {
  ABIERTA: { fondo: '#E0F2FE', texto: '#075985' },
  DIAGNOSTICO: { fondo: '#EDE9FE', texto: '#5B21B6' },
  ESPERA_APROBACION: { fondo: '#FEF3C7', texto: '#92400E' },
  EN_TRABAJO: { fondo: '#DBEAFE', texto: '#1E40AF' },
  LISTA_ENTREGA: { fondo: '#FFEDD5', texto: '#9A3412' },
  ENTREGADA: { fondo: '#DCFCE7', texto: '#166534' },
  CANCELADA: { fondo: '#F1F5F9', texto: '#475569' },
};

/** Muestra el estado con TEXTO y color (no solo color: accesibilidad). */
export function EstadoBadge({ estado }: { estado: EstadoOrden }) {
  const color = COLORES[estado];
  return <Text style={[styles.badge, { backgroundColor: color.fondo, color: color.texto }]}>{ESTADO_LABEL[estado]}</Text>;
}

const styles = StyleSheet.create({
  badge: {
    alignSelf: 'flex-start',
    fontSize: 12,
    fontWeight: '800',
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 99,
    overflow: 'hidden',
  },
});
