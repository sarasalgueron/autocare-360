import { Link } from 'expo-router';
import { Pressable } from 'react-native';
import type { Vehiculo } from '../models/taller';
import { VehiculoCard } from './VehiculoCard';

/** Guia 03: envuelve la tarjeta con un Link. Navega enviando SOLO el id del vehiculo. */
export function VehiculoNavegable({ vehiculo, nombreCliente }: { vehiculo: Vehiculo; nombreCliente: string }) {
  return (
    <Link href={{ pathname: '/vehiculos/[id]', params: { id: String(vehiculo.id) } }} asChild>
      <Pressable accessibilityRole="link" accessibilityLabel={`Ver detalle del vehiculo ${vehiculo.placa}`}>
        <VehiculoCard
          placa={vehiculo.placa}
          marca={vehiculo.marca}
          modelo={vehiculo.modelo}
          anio={vehiculo.anio}
          kilometraje={vehiculo.kilometraje}
          nombreCliente={nombreCliente}
        />
      </Pressable>
    </Link>
  );
}
