import { StyleSheet, Text, View } from 'react-native';
import { PALETTE } from '../theme/palette';

type Props = {
  placa: string;
  marca: string;
  modelo: string;
  anio: number;
  kilometraje: number;
  nombreCliente: string;
};

export function VehiculoCard({ placa, marca, modelo, anio, kilometraje, nombreCliente }: Props) {
  return (
    <View style={styles.tarjeta}>
      <Text style={styles.placa}>{placa}</Text>
      <Text style={styles.detalle}>
        {marca} {modelo} · {anio} · {kilometraje.toLocaleString('es-BO')} km
      </Text>
      <Text style={styles.propietario}>Propietario: {nombreCliente}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  tarjeta: {
    backgroundColor: PALETTE.superficie,
    borderColor: PALETTE.borde,
    borderWidth: 1,
    borderRadius: 14,
    padding: 16,
    marginBottom: 10,
  },
  placa: { color: PALETTE.principal, fontSize: 17, fontWeight: '800', letterSpacing: 0.5 },
  detalle: { color: PALETTE.secundario, fontSize: 14, marginTop: 6 },
  propietario: { color: PALETTE.acento, fontSize: 13, marginTop: 8 },
});
