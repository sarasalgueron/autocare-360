import { Pressable, StyleSheet, Text, View } from 'react-native';
import { PALETTE } from '../theme/palette';

type Props = {
  nombre: string;
  documento: string;
  activo: boolean;
  detalle: string;
  alSeleccionar: () => void;
};

/** Tarjeta presentacional: recibe datos por props y avisa al padre cuando la tocan. */
export function ClienteCard({ nombre, documento, activo, detalle, alSeleccionar }: Props) {
  return (
    <Pressable onPress={alSeleccionar} accessibilityRole="button" accessibilityLabel={`Ver cliente ${nombre}`} style={styles.tarjeta}>
      <View style={styles.fila}>
        <Text style={styles.nombre}>{nombre}</Text>
        <Text style={[styles.estado, !activo && styles.inactivo]}>{activo ? 'ACTIVO' : 'INACTIVO'}</Text>
      </View>
      <Text style={styles.detalle}>CI/NIT {documento}</Text>
      <Text style={styles.detalle}>{detalle}</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  tarjeta: {
    backgroundColor: PALETTE.superficie,
    borderWidth: 1,
    borderColor: PALETTE.borde,
    borderRadius: 16,
    padding: 16,
    marginBottom: 12,
  },
  fila: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between', alignItems: 'center', gap: 8 },
  nombre: { fontSize: 17, fontWeight: '800', color: PALETTE.principal },
  estado: {
    fontSize: 11,
    fontWeight: '800',
    color: PALETTE.acento,
    backgroundColor: PALETTE.acentoClaro,
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 99,
  },
  inactivo: { color: PALETTE.inactivo, backgroundColor: PALETTE.inactivoClaro },
  detalle: { marginTop: 6, color: PALETTE.secundario, fontSize: 13 },
});
