import type { Cliente, Vehiculo } from '../models/taller';

// Datos inventados para practicar (Guias 02-07); NO vienen de PostgreSQL.
export const CLIENTES: readonly Cliente[] = [
  { id: 1, documento: '7845123', nombreCompleto: 'Ana Rojas Paz', email: 'ana@ejemplo.test', telefono: '70010001', activo: true },
  { id: 2, documento: '6589421', nombreCompleto: 'Carlos Mendez', email: 'carlos@ejemplo.test', telefono: '70010002', activo: true },
  { id: 3, documento: '9123476', nombreCompleto: 'Lucia Vargas', email: 'lucia@ejemplo.test', telefono: '', activo: false },
  { id: 4, documento: '7345892', nombreCompleto: 'Diego Suarez', email: '', telefono: '70010004', activo: true },
];

export const VEHICULOS: readonly Vehiculo[] = [
  { id: 101, clienteId: 1, placa: '4567-ABC', marca: 'Toyota', modelo: 'Corolla', anio: 2022, tipo: 'AUTO', kilometraje: 35200 },
  { id: 102, clienteId: 1, placa: '2389-XYZ', marca: 'Suzuki', modelo: 'Vitara', anio: 2021, tipo: 'SUV', kilometraje: 48900 },
  { id: 103, clienteId: 2, placa: '7791-KLM', marca: 'Nissan', modelo: 'Kicks', anio: 2023, tipo: 'SUV', kilometraje: 12050 },
  { id: 104, clienteId: 3, placa: '1045-QRS', marca: 'Kia', modelo: 'Sportage', anio: 2020, tipo: 'CAMIONETA', kilometraje: 80310 },
  { id: 105, clienteId: 3, placa: '3321-MNO', marca: 'Honda', modelo: 'CB190', anio: 2019, tipo: 'MOTO', kilometraje: 15400 },
];
