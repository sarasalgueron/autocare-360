import { createContext, useContext, useReducer, type Dispatch, type ReactNode } from 'react';
import { initialTallerState, tallerReducer, type TallerAction, type TallerState } from './tallerReducer';

type TallerContextValue = TallerState & { dispatch: Dispatch<TallerAction> };

const TallerContext = createContext<TallerContextValue | null>(null);

/** Comparte clientes y vehiculos LOCALES con todas las pantallas sin pasar props pantalla por pantalla. */
export function TallerProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(tallerReducer, initialTallerState);
  return <TallerContext.Provider value={{ ...state, dispatch }}>{children}</TallerContext.Provider>;
}

export function useTaller(): TallerContextValue {
  const contexto = useContext(TallerContext);
  if (!contexto) throw new Error('useTaller requiere TallerProvider en _layout.tsx');
  return contexto;
}
