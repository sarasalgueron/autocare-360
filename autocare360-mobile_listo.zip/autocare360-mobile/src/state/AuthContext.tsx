import { createContext, useContext, useEffect, useState, type ReactNode } from 'react';
import { apiRequest, jsonBody } from '../infra/http/apiClient';
import { tokenStorage } from '../security/tokenStorage';

type LoginResponse = { accessToken: string; expiresIn: number };

type AuthState = {
  token: string | null;
  cargando: boolean;
  login: (usuario: string, contrasena: string) => Promise<void>;
  logout: () => Promise<void>;
};

const AuthContext = createContext<AuthState | null>(null);

/** Guia 11: guarda la sesion para toda la app. Al abrir, recupera el token guardado. */
export function AuthProvider({ children }: { children: ReactNode }) {
  const [token, setToken] = useState<string | null>(null);
  const [cargando, setCargando] = useState(true);

  useEffect(() => {
    tokenStorage
      .leer()
      .then(setToken)
      .catch(() => setToken(null))
      .finally(() => setCargando(false));
    // Si apiClient recibe un 401 con token (vencido), el token se borra y aqui se cierra la sesion.
    const desuscribir = tokenStorage.alInvalidar(() => setToken(null));
    return () => {
      desuscribir();
    };
  }, []);

  async function login(usuario: string, contrasena: string) {
    const respuesta = await apiRequest<LoginResponse>('/auth/login', {
      method: 'POST',
      ...jsonBody({ username: usuario.trim(), password: contrasena }),
    });
    await tokenStorage.guardar(respuesta.accessToken);
    setToken(respuesta.accessToken);
  }

  async function logout() {
    await tokenStorage.borrar();
    setToken(null);
  }

  return <AuthContext.Provider value={{ token, cargando, login, logout }}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const contexto = useContext(AuthContext);
  if (!contexto) throw new Error('useAuth requiere AuthProvider en _layout.tsx');
  return contexto;
}
