import { CLIENTES, VEHICULOS } from '../data/demoData';
import { clienteActivo, clienteExiste, placaOcupada, puedeEliminarCliente } from '../domain/tallerRules';
import type { Cliente, Vehiculo } from '../models/taller';

export type TallerState = { clientes: Cliente[]; vehiculos: Vehiculo[] };

export type TallerAction =
  | { type: 'CLIENTE_CREAR'; payload: Cliente }
  | { type: 'CLIENTE_EDITAR'; payload: Cliente }
  | { type: 'CLIENTE_ELIMINAR'; id: number }
  | { type: 'VEHICULO_CREAR'; payload: Vehiculo }
  | { type: 'VEHICULO_EDITAR'; payload: Vehiculo }
  | { type: 'VEHICULO_ELIMINAR'; id: number };

export const initialTallerState: TallerState = { clientes: [...CLIENTES], vehiculos: [...VEHICULOS] };

/**
 * Reducer (Guia 05): recibe el estado actual y una ACCION, devuelve el estado NUEVO.
 * Nunca modifica el arreglo original (inmutabilidad) y aplica las mismas reglas que el backend.
 */
export function tallerReducer(state: TallerState, action: TallerAction): TallerState {
  switch (action.type) {
    case 'CLIENTE_CREAR':
      if (state.clientes.some((c) => c.id === action.payload.id)) return state;
      return { ...state, clientes: [...state.clientes, action.payload] };
    case 'CLIENTE_EDITAR':
      return { ...state, clientes: state.clientes.map((c) => (c.id === action.payload.id ? action.payload : c)) };
    case 'CLIENTE_ELIMINAR':
      // Regla 1:N: un cliente con vehiculos no se elimina (en el backend responde 409).
      if (!puedeEliminarCliente(action.id, state.vehiculos)) return state;
      return { ...state, clientes: state.clientes.filter((c) => c.id !== action.id) };
    case 'VEHICULO_CREAR':
      if (!clienteActivo(action.payload.clienteId, state.clientes)) return state; // RN-01
      if (state.vehiculos.some((v) => v.id === action.payload.id)) return state;
      if (placaOcupada(action.payload.placa, state.vehiculos)) return state; // RF-15
      return { ...state, vehiculos: [...state.vehiculos, action.payload] };
    case 'VEHICULO_EDITAR':
      if (!clienteExiste(action.payload.clienteId, state.clientes)) return state;
      if (placaOcupada(action.payload.placa, state.vehiculos, action.payload.id)) return state;
      return { ...state, vehiculos: state.vehiculos.map((v) => (v.id === action.payload.id ? action.payload : v)) };
    case 'VEHICULO_ELIMINAR':
      return { ...state, vehiculos: state.vehiculos.filter((v) => v.id !== action.id) };
  }
}

/** En memoria no hay base de datos que genere ids: se calcula el siguiente. */
export const siguienteId = (registros: readonly { id: number }[]): number =>
  Math.max(0, ...registros.map((r) => r.id)) + 1;
