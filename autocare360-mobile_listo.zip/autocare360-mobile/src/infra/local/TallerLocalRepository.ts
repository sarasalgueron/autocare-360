import { CLIENTES, VEHICULOS } from '../../data/demoData';
import type { TallerRepository } from '../../domain/contracts';
import type { Cliente, Vehiculo } from '../../models/taller';

/** Adaptador de ejemplo (Guia 07): implementa el contrato con datos locales; otro podria usar HTTP. */
export class TallerLocalRepository implements TallerRepository {
  async listarClientes(): Promise<Cliente[]> {
    return [...CLIENTES];
  }

  async buscarCliente(id: number): Promise<Cliente | null> {
    return CLIENTES.find((c) => c.id === id) ?? null;
  }

  async listarVehiculos(clienteId?: number): Promise<Vehiculo[]> {
    return VEHICULOS.filter((v) => clienteId === undefined || v.clienteId === clienteId);
  }
}
