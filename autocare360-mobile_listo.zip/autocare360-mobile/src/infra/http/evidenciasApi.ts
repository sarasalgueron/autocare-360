import { Platform } from 'react-native';
import { tokenStorage } from '../../security/tokenStorage';
import { API_URL, ApiError, apiRequest } from './apiClient';

/** Contrato real del backend AutoCare (EvidenciaResponse.java). */
export type EvidenciaDto = {
  id: number;
  ordenId: number;
  descripcion: string;
  nombreArchivo: string;
  tipoContenido: string;
  tamanoBytes: number;
  fechaRegistro: string;
  urlArchivo: string;
};

export function urlImagen(evidencia: EvidenciaDto): string {
  return `${API_URL}${evidencia.urlArchivo}`;
}

/**
 * Guia 13: sube la foto como multipart/form-data con dos partes: "archivo" y "descripcion" (RN-08).
 * En Android, React Native envia el archivo con { uri, name, type }.
 * NO se escribe el header Content-Type a mano: fetch agrega el "boundary" del multipart.
 */
async function subir(ordenId: number, uri: string, mimeType: string, descripcion: string): Promise<EvidenciaDto> {
  const token = await tokenStorage.leer();
  const extension = mimeType === 'image/png' ? 'png' : 'jpg';
  const formulario = new FormData();
  if (Platform.OS === 'web') {
    // En el navegador la imagen es un blob: (solo para probar con "expo start --web").
    const blob = await (await fetch(uri)).blob();
    formulario.append('archivo', blob, `evidencia.${extension}`);
  } else {
    formulario.append('archivo', { uri, name: `evidencia.${extension}`, type: mimeType } as unknown as Blob);
  }
  formulario.append('descripcion', descripcion.trim());

  let respuesta: Response;
  try {
    respuesta = await fetch(`${API_URL}/ordenes/${ordenId}/evidencias`, {
      method: 'POST',
      headers: token ? { Authorization: `Bearer ${token}` } : {},
      body: formulario,
    });
  } catch {
    throw new Error('Error de conexion al subir la foto. Comprueba el backend.');
  }
  const texto = await respuesta.text();
  let datos: unknown = null;
  try {
    datos = texto ? JSON.parse(texto) : null;
  } catch {
    datos = null; // p. ej. un 413 de Tomcat puede venir sin JSON
  }
  if (!respuesta.ok) {
    if (respuesta.status === 401 && token) await tokenStorage.invalidar();
    const razon = datos && typeof datos === 'object' && 'message' in datos ? String((datos as { message: unknown }).message) : '';
    throw new ApiError(respuesta.status, `Subida rechazada (HTTP ${respuesta.status}). ${razon}`);
  }
  return datos as EvidenciaDto;
}

export const evidenciasApi = {
  listar: (ordenId: number) => apiRequest<EvidenciaDto[]>(`/ordenes/${ordenId}/evidencias`),
  subir,
};
