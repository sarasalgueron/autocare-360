import type { VehiculoFormValue } from '../../domain/validaciones';
import { normalizarPlaca } from '../../domain/validaciones';
import type { TipoVehiculo } from '../../models/taller';
import { apiRequest, jsonBody } from './apiClient';

/** Contrato real del backend AutoCare (VehiculoResponse.java). */
export type VehiculoDto = {
  id: number;
  clienteId: number;
  placa: string;
  vin: string | null;
  marca: string;
  modelo: string;
  anio: number;
  color: string | null;
  tipo: TipoVehiculo;
  kilometraje: number;
  activo: boolean;
  fechaRegistro: string;
  /** Optimistic locking: se reenvia en el PUT (Guia 10). */
  version: number;
};

/** Valor del formulario YA validado (clienteId no es null). */
export type VehiculoValido = VehiculoFormValue & { clienteId: number };

function cuerpoDesdeFormulario(valor: VehiculoValido) {
  return {
    clienteId: valor.clienteId,
    placa: normalizarPlaca(valor.placa),
    marca: valor.marca.trim(),
    modelo: valor.modelo.trim(),
    anio: Number(valor.anio),
    tipo: valor.tipo,
    kilometraje: Number(valor.kilometraje),
  };
}

export function vehiculoAFormulario(dto: VehiculoDto): VehiculoFormValue {
  return {
    clienteId: dto.clienteId,
    placa: dto.placa,
    marca: dto.marca,
    modelo: dto.modelo,
    anio: String(dto.anio),
    tipo: dto.tipo,
    kilometraje: String(dto.kilometraje),
  };
}

export const vehiculosApi = {
  listar: () => apiRequest<VehiculoDto[]>('/vehiculos'),
  /** GET /api/vehiculos?clienteId=1 (contrato de la Guia 10). 404 si el cliente no existe. */
  listarPorCliente: (clienteId: number) => apiRequest<VehiculoDto[]>(`/vehiculos?clienteId=${clienteId}`),
  obtener: (id: number) => apiRequest<VehiculoDto>(`/vehiculos/${id}`),
  crear: (valor: VehiculoValido) =>
    apiRequest<VehiculoDto>('/vehiculos', { method: 'POST', ...jsonBody({ ...cuerpoDesdeFormulario(valor), vin: null, color: null }) }),
  /**
   * PUT reemplaza TODO el recurso: conservamos vin, color y activo que la app movil no edita.
   * version: la del registro que se cargo en pantalla; si alguien lo cambio antes -> 409.
   */
  editar: (original: VehiculoDto, valor: VehiculoValido) =>
    apiRequest<VehiculoDto>(`/vehiculos/${original.id}`, {
      method: 'PUT',
      ...jsonBody({
        ...cuerpoDesdeFormulario(valor),
        vin: original.vin,
        color: original.color,
        activo: original.activo,
        version: original.version,
      }),
    }),
  eliminar: (id: number) => apiRequest<null>(`/vehiculos/${id}`, { method: 'DELETE' }),
};
