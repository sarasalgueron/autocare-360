import type { EstadoOrden } from '../../domain/estadoOrden';
import { apiRequest, jsonBody } from './apiClient';

/** Contrato real del backend AutoCare (OrdenServicioResponse.java). */
export type OrdenDto = {
  id: number;
  vehiculoId: number;
  estado: EstadoOrden;
  descripcionProblema: string;
  kilometrajeIngreso: number;
  fechaApertura: string;
  fechaEntrega: string | null;
  kilometrajeSalida: number | null;
  observacionesEntrega: string | null;
  fechaActualizacion: string;
  transicionesPermitidas: EstadoOrden[];
  /** Optimistic locking del backend: si dos personas cambian el estado a la vez, el segundo recibe 409. */
  version: number;
};

export type HistorialDto = {
  id: number;
  estadoAnterior: EstadoOrden | null;
  estadoNuevo: EstadoOrden;
  motivo: string | null;
  fecha: string;
};

export const ordenesApi = {
  listar: (vehiculoId?: number) => apiRequest<OrdenDto[]>(`/ordenes${vehiculoId ? `?vehiculoId=${vehiculoId}` : ''}`),
  obtener: (id: number) => apiRequest<OrdenDto>(`/ordenes/${id}`),
  historial: (id: number) => apiRequest<HistorialDto[]>(`/ordenes/${id}/historial`),
  /** PATCH: solo cambia el estado. El backend valida RN-02 y responde 409 si no corresponde. */
  cambiarEstado: (id: number, estado: EstadoOrden, motivo: string | null) =>
    apiRequest<OrdenDto>(`/ordenes/${id}/estado`, { method: 'PATCH', ...jsonBody({ estado, motivo }) }),
};
