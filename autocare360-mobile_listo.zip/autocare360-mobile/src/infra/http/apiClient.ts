import { tokenStorage } from '../../security/tokenStorage';

/**
 * Guia 08: en el EMULADOR Android, 10.0.2.2 es "la PC anfitriona" (localhost seria el propio telefono).
 * En un telefono fisico: la IP de la PC en la misma red Wi-Fi. Se configura en .env (EXPO_PUBLIC_API_URL).
 */
export const API_URL = process.env.EXPO_PUBLIC_API_URL ?? 'http://10.0.2.2:8080/api';

export class ApiError extends Error {
  readonly status: number;

  constructor(status: number, message: string) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
  }
}

/**
 * Unica puerta HTTP de la app: agrega el token Bearer (si hay sesion), corta a los 10 s,
 * convierte la respuesta en JSON y traduce los errores del backend (ApiError.java) a ApiError.
 */
export async function apiRequest<T>(ruta: string, opciones: RequestInit = {}): Promise<T> {
  if (!ruta.startsWith('/')) throw new Error('La ruta debe comenzar con /');
  const token = await tokenStorage.leer();
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 10000);
  try {
    const respuesta = await fetch(`${API_URL}${ruta}`, {
      ...opciones,
      signal: controller.signal,
      headers: {
        Accept: 'application/json',
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
        ...opciones.headers,
      },
    });
    const texto = await respuesta.text();
    let datos: unknown = null;
    if (texto) {
      try {
        datos = JSON.parse(texto);
      } catch {
        throw new ApiError(502, 'El servidor no envio JSON valido.');
      }
    }
    if (!respuesta.ok) {
      // Token vencido o invalido: cerrar la sesion local para que la app pida login de nuevo.
      if (respuesta.status === 401 && token) await tokenStorage.invalidar();
      throw new ApiError(respuesta.status, mensajeDeError(respuesta.status, datos));
    }
    return datos as T; // 204 (DELETE) -> null
  } catch (error) {
    if (error instanceof ApiError) throw error;
    if (error instanceof Error && error.name === 'AbortError') throw new Error('Tiempo de espera agotado (10 s).');
    // fetch solo lanza cuando NO hubo respuesta: backend apagado, IP incorrecta, sin red.
    throw new Error('Error de conexion. Comprueba la URL y que el backend este encendido.');
  } finally {
    clearTimeout(timeout);
  }
}

function mensajeDeError(status: number, datos: unknown): string {
  // Primero el mensaje que explica el backend (ApiError.message). Ej.: "Usuario o contrasena incorrectos".
  if (datos && typeof datos === 'object' && 'message' in datos) {
    return String((datos as { message: unknown }).message);
  }
  // Un 401 sin cuerpo lo produce Spring Security: token ausente, vencido o falso.
  if (status === 401) return 'Sesion vencida o invalida (401). Vuelve a iniciar sesion.';
  return `Respuesta HTTP ${status}`;
}

export function jsonBody(datos: unknown): RequestInit {
  return { headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(datos) };
}
