import type { ClienteFormValue } from '../../domain/validaciones';
import { apiRequest, jsonBody } from './apiClient';

/** Contrato real del backend AutoCare (ClienteResponse.java). */
export type ClienteDto = {
  id: number;
  documento: string;
  nombreCompleto: string;
  email: string | null;
  telefono: string | null;
  activo: boolean;
  fechaRegistro: string;
  /** Optimistic locking (@Version en Spring Boot): se reenvia en el PUT; si es vieja -> 409. */
  version: number;
};

/** Adaptador (Guia 09-10): si el backend cambia rutas o DTO, solo se toca este archivo. */
function cuerpoBase(valor: ClienteFormValue) {
  return {
    documento: valor.documento.trim(),
    nombreCompleto: valor.nombreCompleto.trim(),
    email: valor.email.trim() ? valor.email.trim().toLowerCase() : null,
    telefono: valor.telefono.trim() || null,
  };
}

export function clienteAFormulario(dto: ClienteDto): ClienteFormValue {
  return {
    documento: dto.documento,
    nombreCompleto: dto.nombreCompleto,
    email: dto.email ?? '',
    telefono: dto.telefono ?? '',
    activo: dto.activo,
  };
}

export const clientesApi = {
  listar: () => apiRequest<ClienteDto[]>('/clientes'),
  obtener: (id: number) => apiRequest<ClienteDto>(`/clientes/${id}`),
  crear: (valor: ClienteFormValue) => apiRequest<ClienteDto>('/clientes', { method: 'POST', ...jsonBody(cuerpoBase(valor)) }),
  /** PUT con la version que se LEYO (Guia 09). Si otra persona guardo antes, el backend responde 409. */
  editar: (id: number, valor: ClienteFormValue, version: number) =>
    apiRequest<ClienteDto>(`/clientes/${id}`, {
      method: 'PUT',
      ...jsonBody({ ...cuerpoBase(valor), activo: valor.activo, version }),
    }),
  eliminar: (id: number) => apiRequest<null>(`/clientes/${id}`, { method: 'DELETE' }),
};
