// Un solo lugar para los colores repetidos: evita variaciones accidentales.
export const PALETTE = {
  fondo: '#F3F6FA',
  superficie: '#FFFFFF',
  principal: '#16324F',
  secundario: '#53647B',
  acento: '#1F6FEB',
  acentoClaro: '#E3EEFF',
  marca: '#F59E0B',
  borde: '#DCE6EE',
  peligro: '#B42318',
  exito: '#067647',
  inactivo: '#8B4E16',
  inactivoClaro: '#FFF1DF',
} as const;
