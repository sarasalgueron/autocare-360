import { useRouter } from 'expo-router';
import { useState } from 'react';
import { ScrollView, StyleSheet, Text, TextInput } from 'react-native';
import { Boton } from '../components/Boton';
import { useAuth } from '../state/AuthContext';
import { PALETTE } from '../theme/palette';
import { mensajeDe } from '../utils/dialogos';

/** Guia 11: POST /api/auth/login -> token JWT guardado con SecureStore. */
export default function LoginScreen() {
  const router = useRouter();
  const { login } = useAuth();
  const [usuario, setUsuario] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [cargando, setCargando] = useState(false);

  async function entrar() {
    if (!usuario.trim() || !password) {
      setError('Usuario y contrasena son obligatorios.');
      return;
    }
    setCargando(true);
    setError('');
    try {
      await login(usuario, password);
      router.replace('/remoto');
    } catch (e) {
      setError(mensajeDe(e));
    } finally {
      setCargando(false);
    }
  }

  return (
    <ScrollView contentContainerStyle={styles.contenido} keyboardShouldPersistTaps="handled">
      <Text style={styles.titulo}>Iniciar sesion</Text>
      <Text style={styles.label}>USUARIO</Text>
      <TextInput accessibilityLabel="Usuario" autoCapitalize="none" value={usuario} onChangeText={setUsuario}
        style={styles.input} placeholder="asesor" />
      <Text style={styles.label}>CONTRASENA</Text>
      <TextInput accessibilityLabel="Contrasena" value={password} onChangeText={setPassword} secureTextEntry
        style={styles.input} placeholder="Contrasena" onSubmitEditing={() => void entrar()} />
      {!!error && <Text accessibilityRole="alert" style={styles.error}>{error}</Text>}
      <Boton texto="Iniciar sesion" alPresionar={() => void entrar()} cargando={cargando} />
      <Text style={styles.ayuda}>
        Usuario de aula: asesor / Clave123!. En produccion: HTTPS y cuentas reales; la contrasena nunca se guarda en el
        telefono, solo el token.
      </Text>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  contenido: { padding: 20, paddingBottom: 45 },
  titulo: { fontSize: 25, fontWeight: '800', color: PALETTE.principal },
  label: { fontWeight: '800', color: PALETTE.principal, marginTop: 23, marginBottom: 10 },
  input: { backgroundColor: '#fff', borderWidth: 1, borderColor: PALETTE.borde, borderRadius: 10, padding: 13 },
  error: { color: PALETTE.peligro, marginTop: 15 },
  ayuda: { color: PALETTE.secundario, marginTop: 22, lineHeight: 21 },
});
