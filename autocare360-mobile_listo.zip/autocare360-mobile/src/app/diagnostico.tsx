import { useState } from 'react';
import { ScrollView, StyleSheet, Text } from 'react-native';
import { Boton } from '../components/Boton';
import { apiRequest, API_URL } from '../infra/http/apiClient';
import { PALETTE } from '../theme/palette';
import { mensajeDe } from '../utils/dialogos';

type Salud = { status: string; application: string };

/** Guia 08: comprueba que el TELEFONO llega al backend (Swagger en la PC no lo demuestra). */
export default function Diagnostico() {
  const [cargando, setCargando] = useState(false);
  const [resultado, setResultado] = useState('Todavia no se hizo la prueba.');

  async function probar() {
    setCargando(true);
    setResultado('Consultando...');
    try {
      const respuesta = await apiRequest<Salud>('/health');
      setResultado(`HTTP 200 - ${respuesta.status} - ${respuesta.application}`);
    } catch (error) {
      setResultado(mensajeDe(error));
    } finally {
      setCargando(false);
    }
  }

  return (
    <ScrollView contentContainerStyle={styles.contenido}>
      <Text style={styles.titulo}>Diagnostico REST</Text>
      <Text style={styles.label}>URL efectiva: {API_URL}</Text>
      <Text style={styles.label}>En el emulador Android, 10.0.2.2 apunta a la PC anfitriona.</Text>
      <Text style={styles.label}>Que Swagger funcione en el navegador NO confirma la conexion desde Android.</Text>
      <Boton texto="Probar GET /health" alPresionar={() => void probar()} cargando={cargando} />
      <Text selectable style={styles.resultado}>{resultado}</Text>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  contenido: { padding: 20 },
  titulo: { fontSize: 24, fontWeight: '800', color: PALETTE.principal },
  label: { color: PALETTE.secundario, marginTop: 16, lineHeight: 22 },
  resultado: { marginTop: 22, padding: 14, backgroundColor: PALETTE.acentoClaro, lineHeight: 23, borderRadius: 10 },
});
