import { Link } from 'expo-router';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { MetricCard } from '../components/MetricCard';
import { useTallerStats } from '../hooks/useTallerStats';
import { useAuth } from '../state/AuthContext';
import { PALETTE } from '../theme/palette';

/** Ruta "/": panel de inicio. Separa lo LOCAL (practica en memoria) de lo REMOTO (PostgreSQL). */
export default function Inicio() {
  const resumen = useTallerStats();
  const { token } = useAuth();
  return (
    <ScrollView contentContainerStyle={styles.contenido}>
      <Text style={styles.titulo}>AutoCare 360 Mobile</Text>
      <Text style={styles.ayuda}>Seguimiento de tus vehiculos y ordenes de servicio del taller.</Text>

      <Text style={styles.seccion}>Taller conectado (PostgreSQL)</Text>
      <Link href={token ? '/remoto' : '/login'} asChild>
        {/* Hijo de <Link asChild>: un solo objeto de estilo (expo-router no acepta arreglos aqui). */}
        <Pressable style={styles.botonDestacado}>
          <Text style={styles.texto}>{token ? 'Entrar al area del taller →' : 'Iniciar sesion →'}</Text>
        </Pressable>
      </Link>
      <Link href="/diagnostico" asChild>
        <Pressable style={styles.secundario}>
          <Text style={styles.textoSecundario}>Diagnostico de conexion (GET /health)</Text>
        </Pressable>
      </Link>

      <Text style={styles.seccion}>Practica local (Guias 03-07, en memoria)</Text>
      <View style={styles.metricas}>
        <MetricCard etiqueta="Clientes" valor={resumen.clientes} />
        <MetricCard etiqueta="Vehiculos" valor={resumen.vehiculos} />
        <MetricCard etiqueta="Sin vehiculos" valor={resumen.sinVehiculos} />
      </View>
      <Link href="/clientes" asChild>
        <Pressable style={styles.boton}>
          <Text style={styles.texto}>Gestionar clientes locales →</Text>
        </Pressable>
      </Link>
      <Link href="/vehiculos" asChild>
        <Pressable style={styles.boton}>
          <Text style={styles.texto}>Gestionar vehiculos locales →</Text>
        </Pressable>
      </Link>
      <Link href="/practica" asChild>
        <Pressable style={styles.secundario}>
          <Text style={styles.textoSecundario}>Practica Guia 02: componentes, props y estado</Text>
        </Pressable>
      </Link>
      <Link href="/ayuda" asChild>
        <Pressable style={styles.secundario}>
          <Text style={styles.textoSecundario}>Ayuda y pruebas de rutas</Text>
        </Pressable>
      </Link>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  contenido: { padding: 20, gap: 12, paddingBottom: 40 },
  titulo: { fontSize: 26, fontWeight: '800', color: PALETTE.principal },
  ayuda: { color: PALETTE.secundario, lineHeight: 23 },
  seccion: { marginTop: 14, fontSize: 13, fontWeight: '800', color: PALETTE.secundario, textTransform: 'uppercase' },
  metricas: { flexDirection: 'row', gap: 10, flexWrap: 'wrap' },
  boton: { padding: 16, borderRadius: 12, backgroundColor: PALETTE.acento },
  botonDestacado: { padding: 16, borderRadius: 12, backgroundColor: PALETTE.principal },
  texto: { fontWeight: '800', color: '#fff', textAlign: 'center' },
  secundario: { padding: 14, borderRadius: 12, backgroundColor: PALETTE.acentoClaro },
  textoSecundario: { fontWeight: '700', color: PALETTE.principal, textAlign: 'center' },
});
