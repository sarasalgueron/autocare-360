import { Link, useRouter } from 'expo-router';
import { FlatList, Pressable, StyleSheet, Text, View } from 'react-native';
import { ClienteCard } from '../../components/ClienteCard';
import { EmptyState } from '../../components/EmptyState';
import { vehiculosDe } from '../../domain/tallerRules';
import { useTaller } from '../../state/TallerContext';
import { PALETTE } from '../../theme/palette';

/** FlatList (Guia 02) solo dibuja las filas visibles: eficiente para listas largas. */
export default function ClientesScreen() {
  const router = useRouter();
  const { clientes, vehiculos } = useTaller();
  return (
    <FlatList
      data={clientes}
      keyExtractor={(c) => String(c.id)}
      contentContainerStyle={styles.contenido}
      ListHeaderComponent={
        <View>
          <Text style={styles.titulo}>Clientes LOCALES</Text>
          <Text style={styles.ayuda}>Se conservan hasta que cierres o recargues la aplicacion.</Text>
          <Link href="/clientes/nuevo" asChild>
            <Pressable style={styles.boton}>
              <Text style={styles.botonTexto}>+ Crear cliente</Text>
            </Pressable>
          </Link>
        </View>
      }
      renderItem={({ item }) => (
        <ClienteCard
          nombre={item.nombreCompleto}
          documento={item.documento}
          activo={item.activo}
          detalle={`${vehiculosDe(item.id, vehiculos).length} vehiculo(s)`}
          alSeleccionar={() => router.push({ pathname: '/clientes/[id]', params: { id: String(item.id) } })}
        />
      )}
      ListEmptyComponent={<EmptyState mensaje="No hay clientes. Crea el primero." />}
    />
  );
}

const styles = StyleSheet.create({
  contenido: { padding: 18, paddingBottom: 40 },
  titulo: { fontSize: 23, fontWeight: '800', color: PALETTE.principal },
  ayuda: { color: PALETTE.secundario, marginTop: 9, marginBottom: 12 },
  boton: { backgroundColor: PALETTE.acento, borderRadius: 11, padding: 15, marginBottom: 18 },
  botonTexto: { color: '#fff', fontWeight: '800', textAlign: 'center' },
});
