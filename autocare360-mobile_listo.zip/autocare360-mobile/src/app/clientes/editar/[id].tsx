import { useLocalSearchParams, useRouter } from 'expo-router';
import { Text, View } from 'react-native';
import { ClienteForm } from '../../../components/ClienteForm';
import { useTaller } from '../../../state/TallerContext';
import { leerIdPositivo } from '../../../utils/routeParams';

export default function EditarCliente() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const { clientes, dispatch } = useTaller();
  const cliente = clientes.find((c) => c.id === leerIdPositivo(id));
  if (!cliente) {
    return (
      <View style={{ padding: 20 }}>
        <Text>Cliente no encontrado.</Text>
      </View>
    );
  }
  const { id: idCliente, ...valorInicial } = cliente;
  return (
    <ClienteForm
      valorInicial={valorInicial}
      textoBoton="Guardar cambios LOCALES"
      alGuardar={(valor) => {
        dispatch({ type: 'CLIENTE_EDITAR', payload: { id: idCliente, ...valor } });
        router.replace({ pathname: '/clientes/[id]', params: { id: String(idCliente) } });
      }}
    />
  );
}
