import { Link, useLocalSearchParams, useRouter } from 'expo-router';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { Boton } from '../../components/Boton';
import { EmptyState } from '../../components/EmptyState';
import { VehiculoNavegable } from '../../components/VehiculoNavegable';
import { vehiculosDe } from '../../domain/tallerRules';
import { useTaller } from '../../state/TallerContext';
import { PALETTE } from '../../theme/palette';
import { avisar, confirmar } from '../../utils/dialogos';
import { leerIdPositivo } from '../../utils/routeParams';

export default function DetalleCliente() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const { clientes, vehiculos, dispatch } = useTaller();
  const cliente = clientes.find((c) => c.id === leerIdPositivo(id));

  if (!cliente) {
    return (
      <View style={styles.contenido}>
        <EmptyState mensaje="Cliente inexistente." />
      </View>
    );
  }
  const asociados = vehiculosDe(cliente.id, vehiculos);

  async function eliminar() {
    if (!cliente) return;
    if (asociados.length > 0) {
      avisar('No se puede eliminar', 'Primero elimina o reasigna sus vehiculos (regla 1:N).');
      return;
    }
    if (await confirmar('Confirmacion', `¿Eliminar a ${cliente.nombreCompleto}?`)) {
      dispatch({ type: 'CLIENTE_ELIMINAR', id: cliente.id });
      router.replace('/clientes');
    }
  }

  return (
    <ScrollView contentContainerStyle={styles.contenido}>
      <Text style={styles.titulo}>{cliente.nombreCompleto}</Text>
      <Text style={styles.dato}>CI/NIT {cliente.documento} · {cliente.activo ? 'ACTIVO' : 'INACTIVO'}</Text>
      <Text style={styles.dato}>{cliente.email || 'Sin correo'} · {cliente.telefono || 'Sin telefono'}</Text>
      <Link href={{ pathname: '/clientes/editar/[id]', params: { id: String(cliente.id) } }} asChild>
        <Pressable style={styles.boton}>
          <Text style={styles.texto}>Editar cliente</Text>
        </Pressable>
      </Link>
      <Boton texto="Eliminar cliente" variante="peligro" alPresionar={() => void eliminar()} />
      <Text style={styles.subtitulo}>Vehiculos asociados: {asociados.length}</Text>
      {asociados.length ? (
        asociados.map((v) => <VehiculoNavegable key={v.id} vehiculo={v} nombreCliente={cliente.nombreCompleto} />)
      ) : (
        <EmptyState mensaje="Este cliente no tiene vehiculos." />
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  contenido: { padding: 18, paddingBottom: 55 },
  titulo: { fontSize: 25, fontWeight: '800', color: PALETTE.principal },
  dato: { marginTop: 10, color: PALETTE.secundario, lineHeight: 22 },
  subtitulo: { fontSize: 18, fontWeight: '800', color: PALETTE.principal, marginVertical: 22 },
  boton: { backgroundColor: PALETTE.acento, borderRadius: 12, padding: 15, marginTop: 20 },
  texto: { color: '#fff', textAlign: 'center', fontWeight: '800' },
});
