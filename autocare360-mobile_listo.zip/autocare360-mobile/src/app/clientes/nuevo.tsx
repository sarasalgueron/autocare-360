import { useRouter } from 'expo-router';
import { ClienteForm } from '../../components/ClienteForm';
import { useTaller } from '../../state/TallerContext';
import { siguienteId } from '../../state/tallerReducer';

export default function NuevoCliente() {
  const router = useRouter();
  const { clientes, dispatch } = useTaller();
  return (
    <ClienteForm
      textoBoton="Crear cliente LOCAL"
      mostrarActivo={false}
      alGuardar={(valor) => {
        dispatch({ type: 'CLIENTE_CREAR', payload: { id: siguienteId(clientes), ...valor, activo: true } });
        router.replace('/clientes');
      }}
    />
  );
}
