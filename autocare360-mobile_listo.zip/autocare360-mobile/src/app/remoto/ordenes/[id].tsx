import { Link, useFocusEffect, useLocalSearchParams } from 'expo-router';
import { useCallback, useState } from 'react';
import { ActivityIndicator, Image, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { Boton } from '../../../components/Boton';
import { EstadoBadge } from '../../../components/EstadoBadge';
import { accionesMovil, esOrdenActiva, type AccionMovil } from '../../../domain/estadoOrden';
import { evidenciasApi, urlImagen, type EvidenciaDto } from '../../../infra/http/evidenciasApi';
import { ordenesApi, type HistorialDto, type OrdenDto } from '../../../infra/http/ordenesApi';
import { useAuth } from '../../../state/AuthContext';
import { PALETTE } from '../../../theme/palette';
import { avisar, confirmar, mensajeDe } from '../../../utils/dialogos';
import { leerIdPositivo } from '../../../utils/routeParams';

/**
 * Detalle de trabajos y evidencias (requisito movil) + transaccion movil principal:
 * el CLIENTE aprueba o rechaza la estimacion (RF-17) -> PATCH /api/ordenes/{id}/estado.
 */
export default function DetalleOrden() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const numero = leerIdPositivo(id);
  const { token } = useAuth();
  const [orden, setOrden] = useState<OrdenDto | null>(null);
  const [historial, setHistorial] = useState<HistorialDto[]>([]);
  const [evidencias, setEvidencias] = useState<EvidenciaDto[]>([]);
  const [error, setError] = useState(numero ? '' : 'ID incorrecto');
  const [cargando, setCargando] = useState(numero !== null);
  const [enviando, setEnviando] = useState(false);
  const [motivo, setMotivo] = useState('');

  const cargar = useCallback(async () => {
    if (!numero) return;
    setCargando(true);
    try {
      const [o, h, e] = await Promise.all([ordenesApi.obtener(numero), ordenesApi.historial(numero), evidenciasApi.listar(numero)]);
      setOrden(o);
      setHistorial(h);
      setEvidencias(e);
      setError('');
    } catch (e) {
      setError(mensajeDe(e));
    } finally {
      setCargando(false);
    }
  }, [numero]);

  // Recarga al volver de "Nueva evidencia" para ver la foto recien subida.
  useFocusEffect(
    useCallback(() => {
      void cargar();
    }, [cargar]),
  );

  async function ejecutar(accion: AccionMovil) {
    if (!orden || enviando) return;
    if (accion.tipo === 'rechazar' && !motivo.trim()) {
      avisar('Falta el motivo', 'Escribe por que rechazas la estimacion.');
      return;
    }
    if (!(await confirmar(accion.etiqueta, `Orden #${orden.id}: ¿confirmas esta accion?`, 'Confirmar'))) return;
    setEnviando(true);
    try {
      const texto =
        accion.tipo === 'aprobar'
          ? 'Cliente aprobo la estimacion desde la app movil'
          : accion.tipo === 'rechazar'
            ? `Cliente rechazo la estimacion: ${motivo.trim()}`
            : motivo.trim() || 'Avance registrado desde la app movil';
      await ordenesApi.cambiarEstado(orden.id, accion.destino, texto);
      setMotivo('');
      await cargar(); // el backend devuelve el estado nuevo y el historial actualizado
    } catch (e) {
      avisar('No se pudo actualizar', mensajeDe(e)); // ej. 409 si la orden ya cambio de estado
    } finally {
      setEnviando(false);
    }
  }

  if (cargando && !orden) return <ActivityIndicator style={{ marginTop: 30 }} />;
  if (error && !orden) return <Text style={styles.errorSolo}>{error}</Text>;
  if (!orden) return null;

  const acciones = accionesMovil(orden.estado, orden.transicionesPermitidas);

  return (
    <ScrollView contentContainerStyle={styles.contenido} keyboardShouldPersistTaps="handled">
      <View style={styles.fila}>
        <Text style={styles.titulo}>Orden #{orden.id}</Text>
        <EstadoBadge estado={orden.estado} />
      </View>
      <Text style={styles.dato}>{orden.descripcionProblema}</Text>
      <Text style={styles.dato}>
        Ingreso: {new Date(orden.fechaApertura).toLocaleString('es-BO')} · {orden.kilometrajeIngreso.toLocaleString('es-BO')} km
      </Text>
      {orden.fechaEntrega && (
        <Text style={styles.dato}>Entregada: {new Date(orden.fechaEntrega).toLocaleString('es-BO')} — {orden.observacionesEntrega}</Text>
      )}
      {!!error && <Text style={styles.error}>{error}</Text>}

      {acciones.length > 0 && (
        <View style={styles.panel}>
          <Text style={styles.subtitulo}>
            {orden.estado === 'ESPERA_APROBACION' ? 'Tu decision sobre la estimacion' : 'Registrar avance (tecnico)'}
          </Text>
          <TextInput accessibilityLabel="Motivo o comentario" value={motivo} onChangeText={setMotivo} multiline
            placeholder={orden.estado === 'ESPERA_APROBACION' ? 'Motivo (obligatorio si rechazas)' : 'Comentario (opcional)'}
            style={styles.input} maxLength={250} />
          {acciones.map((a) => (
            <Boton key={a.destino} texto={a.etiqueta} cargando={enviando} alPresionar={() => void ejecutar(a)}
              variante={a.tipo === 'aprobar' ? 'exito' : a.tipo === 'rechazar' ? 'peligro' : 'primario'} />
          ))}
        </View>
      )}

      <Text style={styles.subtitulo}>Evidencias ({evidencias.length})</Text>
      {evidencias.map((ev) => (
        <View key={ev.id} style={styles.evidencia}>
          <Image
            source={{ uri: urlImagen(ev), headers: token ? { Authorization: `Bearer ${token}` } : undefined }}
            style={styles.foto}
            resizeMode="cover"
            accessibilityLabel={ev.descripcion}
          />
          <Text style={styles.evidenciaTexto}>{ev.descripcion}</Text>
        </View>
      ))}
      {orden.estado !== 'CANCELADA' && (
        <Link href={{ pathname: '/remoto/ordenes/evidencia/[id]', params: { id: String(orden.id) } }} asChild>
          <Pressable style={styles.botonSecundario}>
            <Text style={styles.botonSecundarioTexto}>+ Agregar foto de evidencia</Text>
          </Pressable>
        </Link>
      )}

      <Text style={styles.subtitulo}>Historial</Text>
      {historial.map((h) => (
        <View key={h.id} style={styles.historial}>
          <Text style={styles.historialFecha}>{new Date(h.fecha).toLocaleString('es-BO')}</Text>
          <View style={styles.fila}>
            {h.estadoAnterior ? <EstadoBadge estado={h.estadoAnterior} /> : <Text style={styles.dato}>Inicio</Text>}
            <Text>→</Text>
            <EstadoBadge estado={h.estadoNuevo} />
          </View>
          {!!h.motivo && <Text style={styles.dato}>{h.motivo}</Text>}
        </View>
      ))}
      {!esOrdenActiva(orden.estado) && <Text style={styles.nota}>Esta orden ya esta cerrada.</Text>}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  contenido: { padding: 18, paddingBottom: 50 },
  fila: { flexDirection: 'row', alignItems: 'center', gap: 8, flexWrap: 'wrap' },
  titulo: { fontSize: 24, fontWeight: '800', color: PALETTE.principal, marginRight: 6 },
  subtitulo: { fontSize: 17, fontWeight: '800', color: PALETTE.principal, marginTop: 24, marginBottom: 8 },
  dato: { color: PALETTE.secundario, marginTop: 8, lineHeight: 21 },
  error: { color: PALETTE.peligro, marginTop: 10 },
  errorSolo: { color: PALETTE.peligro, padding: 20 },
  panel: { marginTop: 18, padding: 14, borderRadius: 14, backgroundColor: '#fff', borderWidth: 1, borderColor: PALETTE.borde },
  input: { borderWidth: 1, borderColor: PALETTE.borde, borderRadius: 10, padding: 12, minHeight: 60, backgroundColor: PALETTE.fondo },
  evidencia: { backgroundColor: '#fff', borderRadius: 12, marginBottom: 10, overflow: 'hidden', borderWidth: 1, borderColor: PALETTE.borde },
  foto: { width: '100%', height: 180, backgroundColor: PALETTE.acentoClaro },
  evidenciaTexto: { padding: 10, color: PALETTE.principal },
  botonSecundario: { padding: 14, borderRadius: 12, backgroundColor: PALETTE.acentoClaro },
  botonSecundarioTexto: { textAlign: 'center', fontWeight: '800', color: PALETTE.principal },
  historial: { backgroundColor: '#fff', borderRadius: 12, padding: 12, marginBottom: 8, gap: 6 },
  historialFecha: { fontSize: 12, color: PALETTE.secundario },
  nota: { marginTop: 14, color: PALETTE.secundario },
});
