import * as ImagePicker from 'expo-image-picker';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { useState } from 'react';
import { Image, ScrollView, StyleSheet, Text, TextInput } from 'react-native';
import { Boton } from '../../../../components/Boton';
import { evidenciasApi } from '../../../../infra/http/evidenciasApi';
import { PALETTE } from '../../../../theme/palette';
import { mensajeDe } from '../../../../utils/dialogos';
import { leerIdPositivo } from '../../../../utils/routeParams';

/**
 * Guia 13 (funciones nativas): elegir de la galeria o tomar una foto y subirla como evidencia.
 * - El permiso de camara se pide SOLO cuando el usuario toca "Tomar fotografia".
 * - La galeria usa el selector del sistema (no pide acceso a todas las fotos).
 * - RN-08: la descripcion es obligatoria (tambien la valida el backend).
 */
/** Mismo limite que el backend (Evidencia.TAMANO_MAXIMO_BYTES y spring.servlet.multipart.max-file-size). */
const TAMANO_MAXIMO_BYTES = 5 * 1024 * 1024;

export default function NuevaEvidencia() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const ordenId = leerIdPositivo(id);
  const router = useRouter();
  const [imagen, setImagen] = useState<ImagePicker.ImagePickerAsset | null>(null);
  const [descripcion, setDescripcion] = useState('');
  const [estado, setEstado] = useState('Elige una imagen y escribe que muestra.');
  const [ocupado, setOcupado] = useState(false);

  async function elegir(origen: 'camara' | 'galeria') {
    try {
      if (origen === 'camara') {
        const permiso = await ImagePicker.requestCameraPermissionsAsync();
        if (!permiso.granted) {
          setEstado('Permiso de camara denegado. Puedes usar la galeria o activarlo en Ajustes.');
          return;
        }
      }
      const resultado =
        origen === 'camara'
          ? await ImagePicker.launchCameraAsync({ mediaTypes: ['images'], quality: 0.7 })
          : await ImagePicker.launchImageLibraryAsync({ mediaTypes: ['images'], quality: 0.7 });
      if (resultado.canceled || resultado.assets.length === 0) {
        setEstado('No se eligio ninguna imagen.');
        return;
      }
      const elegida = resultado.assets[0];
      // Se avisa ANTES de subir: el backend igual rechaza (413) una foto de mas de 5 MB.
      if (elegida.fileSize && elegida.fileSize > TAMANO_MAXIMO_BYTES) {
        setImagen(null);
        setEstado(`La foto pesa ${(elegida.fileSize / 1024 / 1024).toFixed(1)} MB: el maximo es 5 MB.`);
        return;
      }
      setImagen(elegida);
      setEstado('Vista previa local: todavia NO se envio al servidor.');
    } catch (e) {
      // Ej.: un emulador sin camara configurada lanza error al abrirla.
      setEstado(`No se pudo abrir ${origen === 'camara' ? 'la camara' : 'la galeria'}: ${mensajeDe(e)}`);
    }
  }

  async function subir() {
    if (!ordenId || !imagen || ocupado) return;
    if (!descripcion.trim()) {
      setEstado('La descripcion es obligatoria (RN-08).');
      return;
    }
    setOcupado(true);
    try {
      const tipo = imagen.mimeType === 'image/png' ? 'image/png' : 'image/jpeg';
      await evidenciasApi.subir(ordenId, imagen.uri, tipo, descripcion);
      router.back();
    } catch (e) {
      setEstado(mensajeDe(e));
    } finally {
      setOcupado(false);
    }
  }

  if (!ordenId) return <Text style={{ padding: 20 }}>Orden invalida.</Text>;

  return (
    <ScrollView contentContainerStyle={styles.contenido} keyboardShouldPersistTaps="handled">
      <Text style={styles.titulo}>Evidencia para la orden #{ordenId}</Text>
      <Text style={styles.ayuda}>El emulador puede no tener camara: usa Galeria o un telefono real.</Text>
      <Boton texto="Seleccionar imagen de galeria" variante="secundario" alPresionar={() => void elegir('galeria')} />
      <Boton texto="Tomar fotografia" variante="secundario" alPresionar={() => void elegir('camara')} />
      {imagen && <Image source={{ uri: imagen.uri }} style={styles.foto} resizeMode="contain" />}
      <Text style={styles.label}>DESCRIPCION (OBLIGATORIA)</Text>
      <TextInput accessibilityLabel="Descripcion de la evidencia" value={descripcion} onChangeText={setDescripcion}
        placeholder="Ej.: pastillas de freno desgastadas" style={styles.input} maxLength={300} multiline />
      <Boton texto="Subir evidencia al backend" alPresionar={() => void subir()} cargando={ocupado} deshabilitado={!imagen} />
      <Text style={styles.ayuda}>{estado}</Text>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  contenido: { padding: 18, paddingBottom: 45 },
  titulo: { fontSize: 21, fontWeight: '800', color: PALETTE.principal },
  ayuda: { color: PALETTE.secundario, marginVertical: 12, lineHeight: 22 },
  label: { marginTop: 18, marginBottom: 9, color: PALETTE.principal, fontWeight: '800' },
  input: { borderWidth: 1, borderColor: PALETTE.borde, backgroundColor: '#fff', borderRadius: 10, padding: 13, minHeight: 70 },
  foto: { width: '100%', height: 220, marginTop: 15, borderRadius: 12, backgroundColor: PALETTE.acentoClaro },
});
