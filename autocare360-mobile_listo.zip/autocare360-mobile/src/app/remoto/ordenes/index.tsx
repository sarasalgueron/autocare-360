import { useFocusEffect, useRouter } from 'expo-router';
import { useCallback, useState } from 'react';
import { ActivityIndicator, FlatList, Pressable, StyleSheet, Text, View } from 'react-native';
import { EmptyState } from '../../../components/EmptyState';
import { EstadoBadge } from '../../../components/EstadoBadge';
import { esOrdenActiva } from '../../../domain/estadoOrden';
import { ordenesApi, type OrdenDto } from '../../../infra/http/ordenesApi';
import { vehiculosApi, type VehiculoDto } from '../../../infra/http/vehiculosApi';
import { PALETTE } from '../../../theme/palette';
import { mensajeDe } from '../../../utils/dialogos';

type Filtro = 'ACTIVAS' | 'APROBAR' | 'TODAS';

/** "Estado de ordenes" (requisito movil del Banco). Las que esperan aprobacion se destacan. */
export default function OrdenesRemotas() {
  const router = useRouter();
  const [ordenes, setOrdenes] = useState<OrdenDto[]>([]);
  const [vehiculos, setVehiculos] = useState<VehiculoDto[]>([]);
  const [filtro, setFiltro] = useState<Filtro>('ACTIVAS');
  const [cargando, setCargando] = useState(true);
  const [error, setError] = useState('');

  const cargar = useCallback(async () => {
    setCargando(true);
    setError('');
    try {
      const [o, v] = await Promise.all([ordenesApi.listar(), vehiculosApi.listar()]);
      setOrdenes(o);
      setVehiculos(v);
    } catch (e) {
      setError(mensajeDe(e));
    } finally {
      setCargando(false);
    }
  }, []);

  useFocusEffect(
    useCallback(() => {
      void cargar();
    }, [cargar]),
  );

  const placaPorId = new Map(vehiculos.map((v) => [v.id, `${v.placa} · ${v.marca} ${v.modelo}`]));
  const porAprobar = ordenes.filter((o) => o.estado === 'ESPERA_APROBACION').length;
  // Dato DERIVADO: se calcula en cada render a partir de "ordenes" y "filtro".
  const visibles = ordenes.filter((o) =>
    filtro === 'TODAS' ? true : filtro === 'APROBAR' ? o.estado === 'ESPERA_APROBACION' : esOrdenActiva(o.estado),
  );

  const chips: { clave: Filtro; texto: string }[] = [
    { clave: 'ACTIVAS', texto: 'En el taller' },
    { clave: 'APROBAR', texto: `Por aprobar (${porAprobar})` },
    { clave: 'TODAS', texto: 'Todas' },
  ];

  return (
    <FlatList
      data={visibles}
      keyExtractor={(o) => String(o.id)}
      contentContainerStyle={styles.contenido}
      ListHeaderComponent={
        <View>
          <Text style={styles.titulo}>Ordenes de servicio</Text>
          {porAprobar > 0 && (
            <Text style={styles.aviso}>Tienes {porAprobar} estimacion(es) esperando tu aprobacion.</Text>
          )}
          <View style={styles.chips}>
            {chips.map((c) => (
              <Pressable key={c.clave} accessibilityRole="button" accessibilityState={{ selected: filtro === c.clave }}
                onPress={() => setFiltro(c.clave)} style={[styles.chip, filtro === c.clave && styles.chipActivo]}>
                <Text style={[styles.chipTexto, filtro === c.clave && styles.chipTextoActivo]}>{c.texto}</Text>
              </Pressable>
            ))}
          </View>
          <Pressable onPress={() => void cargar()} style={styles.recargar}>
            <Text style={styles.recargarTexto}>↻ Recargar</Text>
          </Pressable>
          {cargando && <ActivityIndicator />}
          {!!error && <Text style={styles.error}>{error}</Text>}
        </View>
      }
      renderItem={({ item }) => (
        <Pressable style={[styles.tarjeta, item.estado === 'ESPERA_APROBACION' && styles.tarjetaAprobar]}
          onPress={() => router.push({ pathname: '/remoto/ordenes/[id]', params: { id: String(item.id) } })}>
          <View style={styles.fila}>
            <Text style={styles.numero}>Orden #{item.id}</Text>
            <EstadoBadge estado={item.estado} />
          </View>
          <Text style={styles.vehiculo}>{placaPorId.get(item.vehiculoId) ?? `Vehiculo #${item.vehiculoId}`}</Text>
          <Text style={styles.problema} numberOfLines={2}>{item.descripcionProblema}</Text>
        </Pressable>
      )}
      ListEmptyComponent={!cargando && !error ? <EmptyState mensaje="No hay ordenes para este filtro." /> : undefined}
    />
  );
}

const styles = StyleSheet.create({
  contenido: { padding: 18, paddingBottom: 45 },
  titulo: { fontSize: 22, fontWeight: '800', color: PALETTE.principal },
  aviso: { marginTop: 10, padding: 12, borderRadius: 10, backgroundColor: '#FEF3C7', color: '#92400E', fontWeight: '700' },
  chips: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 14 },
  chip: { paddingVertical: 8, paddingHorizontal: 12, borderRadius: 99, borderWidth: 1, borderColor: PALETTE.borde, backgroundColor: '#fff' },
  chipActivo: { backgroundColor: PALETTE.acento, borderColor: PALETTE.acento },
  chipTexto: { color: PALETTE.principal, fontWeight: '700' },
  chipTextoActivo: { color: '#fff' },
  recargar: { marginVertical: 12 },
  recargarTexto: { color: PALETTE.acento, fontWeight: '700' },
  error: { color: PALETTE.peligro, marginVertical: 10 },
  tarjeta: { backgroundColor: '#fff', borderRadius: 14, padding: 16, marginTop: 10, borderWidth: 1, borderColor: PALETTE.borde, gap: 8 },
  tarjetaAprobar: { borderColor: PALETTE.marca, borderWidth: 2 },
  fila: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', gap: 8, flexWrap: 'wrap' },
  numero: { fontSize: 16, fontWeight: '800', color: PALETTE.principal },
  vehiculo: { color: PALETTE.acento, fontWeight: '700' },
  problema: { color: PALETTE.secundario },
});
