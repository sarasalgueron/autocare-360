import { Redirect, Stack } from 'expo-router';
import { ActivityIndicator, View } from 'react-native';
import { useAuth } from '../../state/AuthContext';
import { PALETTE } from '../../theme/palette';

/**
 * Guia 11: protege TODAS las pantallas de /remoto. Sin token -> /login.
 * Ocultar pantallas NO es seguridad: el backend tambien exige el token (app.security.required=true).
 */
export default function RemotoLayout() {
  const { cargando, token } = useAuth();
  if (cargando) {
    return (
      <View style={{ flex: 1, justifyContent: 'center' }}>
        <ActivityIndicator />
      </View>
    );
  }
  if (!token) return <Redirect href="/login" />;
  return (
    <Stack
      screenOptions={{
        headerStyle: { backgroundColor: PALETTE.principal },
        headerTintColor: PALETTE.superficie,
        contentStyle: { backgroundColor: PALETTE.fondo },
      }}
    >
      <Stack.Screen name="index" options={{ title: 'Taller AutoCare' }} />
      <Stack.Screen name="ordenes/index" options={{ title: 'Estado de ordenes' }} />
      <Stack.Screen name="ordenes/[id]" options={{ title: 'Detalle de la orden' }} />
      <Stack.Screen name="ordenes/evidencia/[id]" options={{ title: 'Nueva evidencia' }} />
      <Stack.Screen name="clientes/index" options={{ title: 'Clientes (PostgreSQL)' }} />
      <Stack.Screen name="clientes/nuevo" options={{ title: 'Nuevo cliente' }} />
      <Stack.Screen name="clientes/[id]" options={{ title: 'Cliente' }} />
      <Stack.Screen name="clientes/editar/[id]" options={{ title: 'Editar cliente' }} />
      <Stack.Screen name="vehiculos/index" options={{ title: 'Vehiculos (PostgreSQL)' }} />
      <Stack.Screen name="vehiculos/nuevo" options={{ title: 'Nuevo vehiculo' }} />
      <Stack.Screen name="vehiculos/[id]" options={{ title: 'Vehiculo' }} />
      <Stack.Screen name="vehiculos/editar/[id]" options={{ title: 'Editar vehiculo' }} />
      <Stack.Screen name="offline" options={{ title: 'Sin conexion (SQLite)' }} />
      <Stack.Screen name="offline/[id]" options={{ title: 'Editar sin conexion' }} />
    </Stack>
  );
}
