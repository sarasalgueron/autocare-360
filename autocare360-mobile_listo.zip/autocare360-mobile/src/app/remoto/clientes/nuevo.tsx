import { useRouter } from 'expo-router';
import { useState } from 'react';
import { ClienteForm } from '../../../components/ClienteForm';
import type { ClienteFormValue } from '../../../domain/validaciones';
import { clientesApi } from '../../../infra/http/clientesApi';
import { avisar, mensajeDe } from '../../../utils/dialogos';

/** POST /api/clientes. "guardando" bloquea el boton para no crear dos veces el mismo cliente. */
export default function NuevoClienteRemoto() {
  const router = useRouter();
  const [guardando, setGuardando] = useState(false);

  async function guardar(valor: ClienteFormValue) {
    if (guardando) return;
    setGuardando(true);
    try {
      await clientesApi.crear(valor);
      router.replace('/remoto/clientes');
    } catch (e) {
      avisar('No se guardo', mensajeDe(e)); // ej. 409 documento duplicado
    } finally {
      setGuardando(false);
    }
  }

  return <ClienteForm textoBoton="Guardar en PostgreSQL" mostrarActivo={false} guardando={guardando} alGuardar={(v) => void guardar(v)} />;
}
