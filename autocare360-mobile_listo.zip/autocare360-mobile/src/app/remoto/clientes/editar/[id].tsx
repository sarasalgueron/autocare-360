import { useLocalSearchParams, useRouter } from 'expo-router';
import { useEffect, useState } from 'react';
import { ActivityIndicator, Text, View } from 'react-native';
import { ClienteForm } from '../../../../components/ClienteForm';
import type { ClienteFormValue } from '../../../../domain/validaciones';
import { clienteAFormulario, clientesApi, type ClienteDto } from '../../../../infra/http/clientesApi';
import { avisar, mensajeDe } from '../../../../utils/dialogos';
import { leerIdPositivo } from '../../../../utils/routeParams';

/** GET /clientes/{id} para precargar y PUT /clientes/{id} para guardar. */
export default function EditarClienteRemoto() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const numero = leerIdPositivo(id);
  const [cliente, setCliente] = useState<ClienteDto | null>(null);
  const [error, setError] = useState(numero ? '' : 'ID incorrecto');
  const [guardando, setGuardando] = useState(false);

  useEffect(() => {
    if (!numero) return;
    let activo = true;
    clientesApi
      .obtener(numero)
      .then((c) => { if (activo) setCliente(c); })
      .catch((e) => { if (activo) setError(mensajeDe(e)); });
    return () => { activo = false; };
  }, [numero]);

  async function guardar(valor: ClienteFormValue) {
    if (!cliente || guardando) return;
    setGuardando(true);
    try {
      await clientesApi.editar(cliente.id, valor, cliente.version); // version leida en el GET
      router.replace({ pathname: '/remoto/clientes/[id]', params: { id: String(cliente.id) } });
    } catch (e) {
      avisar('No se guardo', mensajeDe(e)); // 409: otra persona guardo antes (version vieja) o documento duplicado
    } finally {
      setGuardando(false);
    }
  }

  return (
    <View style={{ flex: 1 }}>
      {!!error && <Text style={{ padding: 15, color: '#B42318' }}>{error}</Text>}
      {!cliente && !error && <ActivityIndicator style={{ marginTop: 20 }} />}
      {cliente && (
        <ClienteForm key={cliente.id} valorInicial={clienteAFormulario(cliente)} textoBoton="Actualizar en PostgreSQL"
          guardando={guardando} alGuardar={(v) => void guardar(v)} />
      )}
    </View>
  );
}
