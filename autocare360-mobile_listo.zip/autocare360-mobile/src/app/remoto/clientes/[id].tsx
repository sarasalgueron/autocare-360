import { Link, useLocalSearchParams, useRouter } from 'expo-router';
import { useEffect, useState } from 'react';
import { ActivityIndicator, Pressable, ScrollView, StyleSheet, Text } from 'react-native';
import { Boton } from '../../../components/Boton';
import { clientesApi, type ClienteDto } from '../../../infra/http/clientesApi';
import { PALETTE } from '../../../theme/palette';
import { avisar, confirmar, mensajeDe } from '../../../utils/dialogos';
import { leerIdPositivo } from '../../../utils/routeParams';

export default function DetalleClienteRemoto() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const idNumerico = leerIdPositivo(id);
  const [cliente, setCliente] = useState<ClienteDto | null>(null);
  const [error, setError] = useState(idNumerico ? '' : 'ID incorrecto');
  const [cargando, setCargando] = useState(idNumerico !== null);
  const [eliminando, setEliminando] = useState(false);

  // Carga dependiente del id. "activo" evita actualizar una pantalla que ya se cerro.
  useEffect(() => {
    if (!idNumerico) return;
    let activo = true;
    clientesApi
      .obtener(idNumerico)
      .then((c) => { if (activo) setCliente(c); })
      .catch((e) => { if (activo) setError(mensajeDe(e)); })
      .finally(() => { if (activo) setCargando(false); });
    return () => { activo = false; };
  }, [idNumerico]);

  async function eliminar() {
    if (!cliente) return;
    if (!(await confirmar('Eliminar de PostgreSQL', `¿Eliminar ${cliente.nombreCompleto}?`))) return;
    setEliminando(true);
    try {
      await clientesApi.eliminar(cliente.id);
      router.replace('/remoto/clientes');
    } catch (e) {
      avisar('No fue posible eliminar', mensajeDe(e)); // ej. 409 si tiene vehiculos
    } finally {
      setEliminando(false);
    }
  }

  return (
    <ScrollView contentContainerStyle={styles.contenido}>
      {cargando && <ActivityIndicator />}
      {!!error && <Text style={styles.error}>{error}</Text>}
      {cliente && (
        <>
          <Text style={styles.titulo}>{cliente.nombreCompleto}</Text>
          <Text style={styles.dato}>CI/NIT: {cliente.documento}</Text>
          <Text style={styles.dato}>Correo: {cliente.email ?? '-'}</Text>
          <Text style={styles.dato}>Telefono: {cliente.telefono ?? '-'}</Text>
          <Text style={styles.dato}>Estado: {cliente.activo ? 'ACTIVO' : 'INACTIVO'}</Text>
          <Text style={styles.dato}>Version en BD: {cliente.version}</Text>
          <Link href={{ pathname: '/remoto/clientes/editar/[id]', params: { id: String(cliente.id) } }} asChild>
            <Pressable style={styles.boton}>
              <Text style={styles.blanco}>Editar registro REMOTO</Text>
            </Pressable>
          </Link>
          <Boton texto="Eliminar en PostgreSQL" variante="peligro" cargando={eliminando} alPresionar={() => void eliminar()} />
          <Text style={styles.nota}>Si tiene vehiculos, el backend rechaza la eliminacion con 409.</Text>
        </>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  contenido: { padding: 20, paddingBottom: 45 },
  titulo: { fontSize: 24, fontWeight: '800', color: PALETTE.principal },
  dato: { color: PALETTE.secundario, marginTop: 12 },
  nota: { color: PALETTE.secundario, marginTop: 14, fontSize: 13 },
  error: { color: PALETTE.peligro },
  boton: { backgroundColor: PALETTE.acento, padding: 16, borderRadius: 12, marginTop: 22 },
  blanco: { color: '#fff', fontWeight: '800', textAlign: 'center' },
});
