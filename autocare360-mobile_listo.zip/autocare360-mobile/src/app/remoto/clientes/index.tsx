import { Link, useFocusEffect, useRouter } from 'expo-router';
import { useCallback, useState } from 'react';
import { ActivityIndicator, FlatList, Pressable, StyleSheet, Text, View } from 'react-native';
import { ClienteCard } from '../../../components/ClienteCard';
import { EmptyState } from '../../../components/EmptyState';
import { clientesApi, type ClienteDto } from '../../../infra/http/clientesApi';
import { PALETTE } from '../../../theme/palette';
import { mensajeDe } from '../../../utils/dialogos';

/** Guia 09: GET /api/clientes. useFocusEffect recarga cada vez que la pantalla vuelve a verse. */
export default function ClientesRemotos() {
  const router = useRouter();
  const [lista, setLista] = useState<ClienteDto[]>([]);
  const [cargando, setCargando] = useState(true);
  const [error, setError] = useState('');

  const cargar = useCallback(async () => {
    setCargando(true);
    setError('');
    try {
      setLista(await clientesApi.listar());
    } catch (e) {
      setError(mensajeDe(e));
    } finally {
      setCargando(false);
    }
  }, []);

  useFocusEffect(
    useCallback(() => {
      void cargar();
    }, [cargar]),
  );

  return (
    <FlatList
      contentContainerStyle={styles.contenido}
      data={lista}
      keyExtractor={(item) => String(item.id)}
      ListHeaderComponent={
        <View>
          <Text style={styles.titulo}>Clientes en PostgreSQL</Text>
          <Link href="/remoto/clientes/nuevo" asChild>
            <Pressable style={styles.boton}>
              <Text style={styles.blanco}>+ Nuevo cliente REMOTO</Text>
            </Pressable>
          </Link>
          <Pressable onPress={() => void cargar()} style={styles.recargar}>
            <Text style={styles.recargarTexto}>↻ Recargar lista</Text>
          </Pressable>
          {cargando && <ActivityIndicator />}
          {!!error && <Text style={styles.error}>{error}</Text>}
        </View>
      }
      renderItem={({ item }) => (
        <ClienteCard
          nombre={item.nombreCompleto}
          documento={item.documento}
          activo={item.activo}
          detalle={`${item.email ?? 'Sin correo'} · Version ${item.version}`}
          alSeleccionar={() => router.push({ pathname: '/remoto/clientes/[id]', params: { id: String(item.id) } })}
        />
      )}
      ListEmptyComponent={!cargando && !error ? <EmptyState mensaje="No existen clientes remotos." /> : undefined}
    />
  );
}

const styles = StyleSheet.create({
  contenido: { padding: 18, paddingBottom: 45 },
  titulo: { fontSize: 23, fontWeight: '800', color: PALETTE.principal },
  boton: { backgroundColor: PALETTE.acento, borderRadius: 12, padding: 15, marginVertical: 15 },
  blanco: { color: '#fff', fontWeight: '800', textAlign: 'center' },
  recargar: { marginBottom: 10 },
  recargarTexto: { color: PALETTE.acento, fontWeight: '700' },
  error: { color: PALETTE.peligro, marginVertical: 10 },
});
