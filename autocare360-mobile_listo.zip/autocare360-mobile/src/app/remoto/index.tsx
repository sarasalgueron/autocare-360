import { Link, useRouter } from 'expo-router';
import { Pressable, ScrollView, StyleSheet, Text } from 'react-native';
import { Boton } from '../../components/Boton';
import { useAuth } from '../../state/AuthContext';
import { PALETTE } from '../../theme/palette';
import { avisar, mensajeDe } from '../../utils/dialogos';

/** Menu del area protegida. Todo lo de aqui consulta Spring Boot con el token Bearer. */
export default function AreaRemota() {
  const router = useRouter();
  const { logout } = useAuth();

  async function salir() {
    try {
      await logout();
      router.replace('/login');
    } catch (e) {
      avisar('Error al cerrar sesion', mensajeDe(e));
    }
  }

  return (
    <ScrollView contentContainerStyle={styles.contenido}>
      <Text style={styles.titulo}>Taller conectado — PostgreSQL</Text>
      <Text style={styles.ayuda}>Las siguientes operaciones usan tu token. Si vence, vuelve a iniciar sesion.</Text>

      <Link href="/remoto/ordenes" asChild>
        <Pressable style={styles.botonDestacado}>
          <Text style={styles.blanco}>Estado de ordenes y aprobaciones</Text>
        </Pressable>
      </Link>
      <Link href="/remoto/vehiculos" asChild>
        <Pressable style={styles.boton}>
          <Text style={styles.blanco}>Vehiculos (CRUD REST)</Text>
        </Pressable>
      </Link>
      <Link href="/remoto/clientes" asChild>
        <Pressable style={styles.boton}>
          <Text style={styles.blanco}>Clientes (CRUD REST)</Text>
        </Pressable>
      </Link>
      <Link href="/remoto/offline" asChild>
        <Pressable style={styles.boton}>
          <Text style={styles.blanco}>Sin conexion: SQLite y sincronizacion</Text>
        </Pressable>
      </Link>
      <Boton texto="Cerrar sesion" variante="peligro" alPresionar={() => void salir()} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  contenido: { padding: 20 },
  titulo: { fontSize: 22, fontWeight: '800', color: PALETTE.principal },
  ayuda: { color: PALETTE.secundario, lineHeight: 23, marginVertical: 15 },
  boton: { backgroundColor: PALETTE.acento, borderRadius: 12, padding: 16, marginBottom: 13 },
  botonDestacado: { backgroundColor: PALETTE.principal, borderRadius: 12, padding: 16, marginBottom: 13 },
  blanco: { color: '#fff', fontWeight: '800', textAlign: 'center' },
});
