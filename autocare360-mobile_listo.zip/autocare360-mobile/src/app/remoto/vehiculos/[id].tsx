import { Link, useLocalSearchParams, useRouter } from 'expo-router';
import { useEffect, useState } from 'react';
import { ActivityIndicator, Pressable, ScrollView, StyleSheet, Text } from 'react-native';
import { Boton } from '../../../components/Boton';
import { EstadoBadge } from '../../../components/EstadoBadge';
import { clientesApi, type ClienteDto } from '../../../infra/http/clientesApi';
import { ordenesApi, type OrdenDto } from '../../../infra/http/ordenesApi';
import { vehiculosApi, type VehiculoDto } from '../../../infra/http/vehiculosApi';
import { PALETTE } from '../../../theme/palette';
import { avisar, confirmar, mensajeDe } from '../../../utils/dialogos';
import { leerIdPositivo } from '../../../utils/routeParams';

/** Detalle del vehiculo + su propietario + sus ordenes de servicio (historia en el taller). */
export default function DetalleVehiculoRemoto() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const numero = leerIdPositivo(id);
  const [vehiculo, setVehiculo] = useState<VehiculoDto | null>(null);
  const [propietario, setPropietario] = useState<ClienteDto | null>(null);
  const [ordenes, setOrdenes] = useState<OrdenDto[]>([]);
  const [error, setError] = useState(numero ? '' : 'ID incorrecto');
  const [cargando, setCargando] = useState(numero !== null);

  useEffect(() => {
    if (!numero) return;
    let vivo = true;
    (async () => {
      try {
        const v = await vehiculosApi.obtener(numero);
        const [c, o] = await Promise.all([clientesApi.obtener(v.clienteId), ordenesApi.listar(v.id)]);
        if (vivo) {
          setVehiculo(v);
          setPropietario(c);
          setOrdenes(o);
        }
      } catch (e) {
        if (vivo) setError(mensajeDe(e));
      } finally {
        if (vivo) setCargando(false);
      }
    })();
    return () => { vivo = false; };
  }, [numero]);

  async function eliminar() {
    if (!vehiculo) return;
    if (!(await confirmar('Eliminar de PostgreSQL', `¿Eliminar ${vehiculo.placa}?`))) return;
    try {
      await vehiculosApi.eliminar(vehiculo.id);
      router.replace('/remoto/vehiculos');
    } catch (e) {
      avisar('No se pudo eliminar', mensajeDe(e)); // 409 si tiene ordenes
    }
  }

  return (
    <ScrollView contentContainerStyle={styles.contenido}>
      {cargando && <ActivityIndicator />}
      {!!error && <Text style={styles.error}>{error}</Text>}
      {vehiculo && (
        <>
          <Text style={styles.titulo}>{vehiculo.placa}</Text>
          <Text style={styles.dato}>
            {vehiculo.marca} {vehiculo.modelo} · {vehiculo.anio} · {vehiculo.tipo}
          </Text>
          <Text style={styles.dato}>Kilometraje: {vehiculo.kilometraje.toLocaleString('es-BO')} km</Text>
          <Text style={styles.dato}>Propietario: {propietario?.nombreCompleto ?? `Cliente #${vehiculo.clienteId}`}</Text>
          <Text style={styles.dato}>clienteId: {vehiculo.clienteId} · version: {vehiculo.version}</Text>

          <Text style={styles.subtitulo}>Ordenes de servicio ({ordenes.length})</Text>
          {ordenes.map((o) => (
            <Pressable key={o.id} style={styles.orden}
              onPress={() => router.push({ pathname: '/remoto/ordenes/[id]', params: { id: String(o.id) } })}>
              <Text style={styles.ordenTitulo}>Orden #{o.id}</Text>
              <EstadoBadge estado={o.estado} />
              <Text style={styles.dato} numberOfLines={2}>{o.descripcionProblema}</Text>
            </Pressable>
          ))}

          <Link href={{ pathname: '/remoto/vehiculos/editar/[id]', params: { id: String(vehiculo.id) } }} asChild>
            <Pressable style={styles.boton}>
              <Text style={styles.blanco}>Editar REMOTO</Text>
            </Pressable>
          </Link>
          <Boton texto="Eliminar REMOTO" variante="peligro" alPresionar={() => void eliminar()} />
        </>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  contenido: { padding: 20, paddingBottom: 45 },
  titulo: { fontSize: 25, fontWeight: '800', color: PALETTE.principal },
  subtitulo: { fontSize: 18, fontWeight: '800', color: PALETTE.principal, marginTop: 24, marginBottom: 6 },
  dato: { marginTop: 10, color: PALETTE.secundario },
  error: { color: PALETTE.peligro },
  orden: { backgroundColor: '#fff', borderRadius: 12, padding: 14, marginTop: 8, gap: 6, borderWidth: 1, borderColor: PALETTE.borde },
  ordenTitulo: { fontWeight: '800', color: PALETTE.principal },
  boton: { backgroundColor: PALETTE.acento, borderRadius: 12, padding: 15, marginTop: 22 },
  blanco: { color: '#fff', textAlign: 'center', fontWeight: '800' },
});
