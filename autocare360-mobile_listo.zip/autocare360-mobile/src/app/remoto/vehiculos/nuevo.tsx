import { useRouter } from 'expo-router';
import { useEffect, useState } from 'react';
import { ActivityIndicator, Text } from 'react-native';
import { VehiculoForm } from '../../../components/VehiculoForm';
import { clientesApi, type ClienteDto } from '../../../infra/http/clientesApi';
import { vehiculosApi, type VehiculoValido } from '../../../infra/http/vehiculosApi';
import { avisar, mensajeDe } from '../../../utils/dialogos';

/** POST /api/vehiculos con el clienteId elegido: asi se PERSISTE la relacion 1:N (FK cliente_id). */
export default function NuevoVehiculoRemoto() {
  const router = useRouter();
  const [clientes, setClientes] = useState<ClienteDto[] | null>(null);
  const [error, setError] = useState('');
  const [guardando, setGuardando] = useState(false);

  useEffect(() => {
    let vivo = true;
    clientesApi
      .listar()
      .then((c) => { if (vivo) setClientes(c); })
      .catch((e) => { if (vivo) setError(mensajeDe(e)); });
    return () => { vivo = false; };
  }, []);

  async function guardar(valor: VehiculoValido) {
    if (guardando) return;
    setGuardando(true);
    try {
      await vehiculosApi.crear(valor);
      router.replace('/remoto/vehiculos');
    } catch (e) {
      avisar('No se guardo', mensajeDe(e)); // 409 placa duplicada o propietario inactivo (RN-01)
    } finally {
      setGuardando(false);
    }
  }

  if (error) return <Text style={{ padding: 20, color: '#B42318' }}>{error}</Text>;
  if (!clientes) return <ActivityIndicator style={{ marginTop: 20 }} />;
  if (!clientes.some((c) => c.activo)) return <Text style={{ padding: 20 }}>Primero registra un cliente activo.</Text>;
  return (
    <VehiculoForm
      propietarios={clientes.map((c) => ({ id: c.id, nombre: c.nombreCompleto, activo: c.activo }))}
      textoBoton="Guardar vehiculo en PostgreSQL"
      guardando={guardando}
      alGuardar={(v) => void guardar(v)}
    />
  );
}
