import { useLocalSearchParams, useRouter } from 'expo-router';
import { useEffect, useState } from 'react';
import { ActivityIndicator, Text } from 'react-native';
import { VehiculoForm } from '../../../../components/VehiculoForm';
import { clientesApi, type ClienteDto } from '../../../../infra/http/clientesApi';
import { vehiculoAFormulario, vehiculosApi, type VehiculoDto, type VehiculoValido } from '../../../../infra/http/vehiculosApi';
import { avisar, mensajeDe } from '../../../../utils/dialogos';
import { leerIdPositivo } from '../../../../utils/routeParams';

/** PUT /api/vehiculos/{id}. Cambiar el propietario = reasignar el vehiculo (actualiza la FK). */
export default function EditarVehiculoRemoto() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const numero = leerIdPositivo(id);
  const [vehiculo, setVehiculo] = useState<VehiculoDto | null>(null);
  const [clientes, setClientes] = useState<ClienteDto[]>([]);
  const [error, setError] = useState(numero ? '' : 'ID incorrecto');
  const [guardando, setGuardando] = useState(false);

  useEffect(() => {
    if (!numero) return;
    let vivo = true;
    Promise.all([vehiculosApi.obtener(numero), clientesApi.listar()])
      .then(([v, c]) => {
        if (vivo) {
          setVehiculo(v);
          setClientes(c);
        }
      })
      .catch((e) => { if (vivo) setError(mensajeDe(e)); });
    return () => { vivo = false; };
  }, [numero]);

  async function guardar(valor: VehiculoValido) {
    if (!vehiculo || guardando) return;
    setGuardando(true);
    try {
      await vehiculosApi.editar(vehiculo, valor);
      router.replace({ pathname: '/remoto/vehiculos/[id]', params: { id: String(vehiculo.id) } });
    } catch (e) {
      avisar('No se guardo', mensajeDe(e)); // 409: kilometraje menor, placa duplicada o version vieja
    } finally {
      setGuardando(false);
    }
  }

  if (error) return <Text style={{ padding: 20, color: '#B42318' }}>{error}</Text>;
  if (!vehiculo) return <ActivityIndicator style={{ marginTop: 20 }} />;
  return (
    <VehiculoForm
      key={vehiculo.id}
      propietarios={clientes.map((c) => ({ id: c.id, nombre: c.nombreCompleto, activo: c.activo }))}
      valorInicial={vehiculoAFormulario(vehiculo)}
      textoBoton="Actualizar en PostgreSQL"
      guardando={guardando}
      alGuardar={(v) => void guardar(v)}
    />
  );
}
