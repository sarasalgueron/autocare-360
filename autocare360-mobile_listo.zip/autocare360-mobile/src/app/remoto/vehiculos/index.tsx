import { Link, useFocusEffect, useRouter } from 'expo-router';
import { useCallback, useState } from 'react';
import { ActivityIndicator, FlatList, Pressable, StyleSheet, Text, View } from 'react-native';
import { EmptyState } from '../../../components/EmptyState';
import { VehiculoCard } from '../../../components/VehiculoCard';
import { clientesApi, type ClienteDto } from '../../../infra/http/clientesApi';
import { vehiculosApi, type VehiculoDto } from '../../../infra/http/vehiculosApi';
import { PALETTE } from '../../../theme/palette';
import { mensajeDe } from '../../../utils/dialogos';

/** "Mis vehiculos": carga vehiculos y clientes EN PARALELO (Promise.all) y resuelve el propietario con un Map. */
export default function VehiculosRemotos() {
  const router = useRouter();
  const [vehiculos, setVehiculos] = useState<VehiculoDto[]>([]);
  const [clientes, setClientes] = useState<ClienteDto[]>([]);
  const [error, setError] = useState('');
  const [cargando, setCargando] = useState(true);

  const cargar = useCallback(async () => {
    setCargando(true);
    setError('');
    try {
      const [v, c] = await Promise.all([vehiculosApi.listar(), clientesApi.listar()]);
      setVehiculos(v);
      setClientes(c);
    } catch (e) {
      setError(mensajeDe(e));
    } finally {
      setCargando(false);
    }
  }, []);

  useFocusEffect(
    useCallback(() => {
      void cargar();
    }, [cargar]),
  );

  const nombrePorId = new Map(clientes.map((c) => [c.id, c.nombreCompleto]));

  return (
    <FlatList
      data={vehiculos}
      keyExtractor={(v) => String(v.id)}
      contentContainerStyle={styles.contenido}
      ListHeaderComponent={
        <View>
          <Text style={styles.titulo}>Vehiculos en PostgreSQL</Text>
          <Link href="/remoto/vehiculos/nuevo" asChild>
            <Pressable style={styles.boton}>
              <Text style={styles.blanco}>+ Registrar vehiculo REMOTO</Text>
            </Pressable>
          </Link>
          <Pressable onPress={() => void cargar()} style={styles.recargar}>
            <Text style={styles.recargarTexto}>↻ Recargar</Text>
          </Pressable>
          {cargando && <ActivityIndicator />}
          {!!error && <Text style={styles.error}>{error}</Text>}
        </View>
      }
      renderItem={({ item }) => (
        <Pressable onPress={() => router.push({ pathname: '/remoto/vehiculos/[id]', params: { id: String(item.id) } })}>
          <VehiculoCard
            placa={item.placa}
            marca={item.marca}
            modelo={item.modelo}
            anio={item.anio}
            kilometraje={item.kilometraje}
            nombreCliente={nombrePorId.get(item.clienteId) ?? `Cliente #${item.clienteId}`}
          />
        </Pressable>
      )}
      ListEmptyComponent={!cargando && !error ? <EmptyState mensaje="No existen vehiculos remotos." /> : undefined}
    />
  );
}

const styles = StyleSheet.create({
  contenido: { padding: 18, paddingBottom: 45 },
  titulo: { fontSize: 22, fontWeight: '800', color: PALETTE.principal },
  boton: { backgroundColor: PALETTE.acento, padding: 15, borderRadius: 12, marginVertical: 15 },
  blanco: { color: '#fff', textAlign: 'center', fontWeight: '800' },
  recargar: { marginBottom: 10 },
  recargarTexto: { color: PALETTE.acento, fontWeight: '700' },
  error: { color: PALETTE.peligro, marginVertical: 10 },
});
