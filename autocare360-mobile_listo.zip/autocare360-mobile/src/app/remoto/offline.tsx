import { useFocusEffect, useRouter } from 'expo-router';
import { useCallback, useState } from 'react';
import { ActivityIndicator, FlatList, Pressable, StyleSheet, Text, View } from 'react-native';
import { Boton } from '../../components/Boton';
import { EmptyState } from '../../components/EmptyState';
import { contarPendientes, descargarClientes, listarCache, sincronizarPendientes, type ClienteCache } from '../../offline/cache';
import { PALETTE } from '../../theme/palette';
import { mensajeDe } from '../../utils/dialogos';

/**
 * Guia 12: memoria (useState) se borra al cerrar la app; SQLite queda en el telefono; PostgreSQL es la verdad.
 * No se sincroniza automaticamente: el usuario decide cuando enviar (evita duplicados con mala senal).
 */
export default function Offline() {
  const router = useRouter();
  const [lista, setLista] = useState<ClienteCache[]>([]);
  const [pendientes, setPendientes] = useState(0);
  const [trabajando, setTrabajando] = useState(false);
  const [mensaje, setMensaje] = useState('La copia local puede leerse sin conexion.');

  const cargar = useCallback(async () => {
    try {
      setLista(await listarCache());
      setPendientes(await contarPendientes());
    } catch (e) {
      setMensaje(`SQLite: ${mensajeDe(e)}`);
    }
  }, []);

  useFocusEffect(
    useCallback(() => {
      void cargar();
    }, [cargar]),
  );

  async function ejecutar(accion: 'descargar' | 'sincronizar') {
    setTrabajando(true);
    try {
      if (accion === 'descargar') {
        const n = await descargarClientes();
        setMensaje(`${n} clientes descargados para consulta sin conexion.`);
      } else {
        const r = await sincronizarPendientes();
        setMensaje(`${r.correctos} cambio(s) aplicados. ${r.fallidos.length} fallido(s). ${r.fallidos.join('; ')}`);
      }
      await cargar();
    } catch (e) {
      setMensaje(mensajeDe(e));
    } finally {
      setTrabajando(false);
    }
  }

  return (
    <FlatList
      data={lista}
      keyExtractor={(c) => String(c.id)}
      contentContainerStyle={styles.contenido}
      ListHeaderComponent={
        <View>
          <Text style={styles.titulo}>SQLite: copia local y cola manual</Text>
          <Text style={styles.ayuda}>Cambios pendientes de enviar: {pendientes}</Text>
          <Boton texto="Descargar clientes desde el backend" alPresionar={() => void ejecutar('descargar')} deshabilitado={trabajando} />
          <Boton texto="Sincronizar cambios pendientes" variante="exito" alPresionar={() => void ejecutar('sincronizar')} deshabilitado={trabajando} />
          {trabajando && <ActivityIndicator style={{ marginTop: 10 }} />}
          <Text style={styles.ayuda}>{mensaje}</Text>
        </View>
      }
      renderItem={({ item }) => (
        <Pressable style={styles.tarjeta}
          onPress={() => router.push({ pathname: '/remoto/offline/[id]', params: { id: String(item.id) } })}>
          <Text style={styles.nombre}>{item.nombreCompleto}</Text>
          <Text style={styles.detalle}>{item.email || 'Sin correo'} · v{item.version} · Toca para editar sin red</Text>
        </Pressable>
      )}
      ListEmptyComponent={<EmptyState mensaje="La copia local esta vacia. Con conexion, pulsa Descargar." />}
    />
  );
}

const styles = StyleSheet.create({
  contenido: { padding: 18, paddingBottom: 45 },
  titulo: { fontSize: 22, fontWeight: '800', color: PALETTE.principal },
  ayuda: { color: PALETTE.secundario, marginVertical: 12, lineHeight: 22 },
  tarjeta: { padding: 14, backgroundColor: '#fff', marginTop: 10, borderRadius: 12, borderWidth: 1, borderColor: PALETTE.borde },
  nombre: { fontWeight: '800', color: PALETTE.principal },
  detalle: { color: PALETTE.secundario, marginTop: 4 },
});
