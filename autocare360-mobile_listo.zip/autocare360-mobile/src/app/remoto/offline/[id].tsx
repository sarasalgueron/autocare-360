import { useLocalSearchParams, useRouter } from 'expo-router';
import { useEffect, useState } from 'react';
import { ActivityIndicator, StyleSheet, Text, View } from 'react-native';
import { Boton } from '../../../components/Boton';
import { ClienteForm } from '../../../components/ClienteForm';
import type { ClienteFormValue } from '../../../domain/validaciones';
import { dejarPendiente, descartarPendiente, listarCache, tienePendiente, type ClienteCache } from '../../../offline/cache';
import { PALETTE } from '../../../theme/palette';
import { avisar, confirmar, mensajeDe } from '../../../utils/dialogos';
import { leerIdPositivo } from '../../../utils/routeParams';

/** Edita la copia local y deja el cambio en la cola pending_updates (sin tocar la red). */
export default function EditorOffline() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const numero = leerIdPositivo(id);
  const [cliente, setCliente] = useState<ClienteCache | null>(null);
  const [pendiente, setPendiente] = useState(false);
  const [buscando, setBuscando] = useState(true);

  useEffect(() => {
    let activo = true;
    (async () => {
      try {
        const encontrado = (await listarCache()).find((x) => x.id === numero) ?? null;
        const hayPendiente = encontrado ? await tienePendiente(encontrado.id) : false;
        if (activo) {
          setCliente(encontrado);
          setPendiente(hayPendiente);
        }
      } finally {
        if (activo) setBuscando(false);
      }
    })();
    return () => { activo = false; };
  }, [numero]);

  async function guardar(valor: ClienteFormValue) {
    if (!cliente) return;
    try {
      // Conserva cliente.version: es la version que se leyo; el servidor decide si sigue vigente.
      await dejarPendiente({ ...cliente, ...valor });
      avisar('Guardado en cola local', 'Se enviara cuando pulses Sincronizar con conexion.');
      router.replace('/remoto/offline');
    } catch (e) {
      avisar('SQLite', mensajeDe(e));
    }
  }

  // Resolucion manual de un conflicto 409: se descarta el cambio local y se recupera el dato del servidor.
  async function descartar() {
    if (!cliente) return;
    if (!(await confirmar('Descartar cambio', 'Se perdera el cambio local y se traera el dato del servidor.', 'Descartar'))) return;
    try {
      await descartarPendiente(cliente.id);
      router.replace('/remoto/offline');
    } catch (e) {
      avisar('Necesitas conexion', mensajeDe(e));
    }
  }

  if (buscando) return <ActivityIndicator style={{ marginTop: 20 }} />;
  if (!cliente) {
    return (
      <View style={{ padding: 20 }}>
        <Text>Ese cliente no esta en la copia local.</Text>
      </View>
    );
  }
  const { id: _id, version, ...valorInicial } = cliente;
  return (
    <View style={{ flex: 1 }}>
      <View style={styles.cabecera}>
        <Text style={styles.dato}>Version leida del servidor: {version}</Text>
        {pendiente && (
          <>
            <Text style={styles.aviso}>Este cliente tiene un cambio PENDIENTE de sincronizar.</Text>
            <Boton texto="Descartar cambio pendiente" variante="secundario" alPresionar={() => void descartar()} />
          </>
        )}
      </View>
      <ClienteForm valorInicial={valorInicial} textoBoton="Guardar cambio PENDIENTE" alGuardar={(v) => void guardar(v)} />
    </View>
  );
}

const styles = StyleSheet.create({
  cabecera: { paddingHorizontal: 18, paddingTop: 14 },
  dato: { color: PALETTE.secundario },
  aviso: { marginTop: 8, color: '#92400E', fontWeight: '700' },
});
