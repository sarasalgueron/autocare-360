import { useRouter } from 'expo-router';
import { VehiculoForm } from '../../components/VehiculoForm';
import { normalizarPlaca } from '../../domain/validaciones';
import { placaOcupada } from '../../domain/tallerRules';
import { useTaller } from '../../state/TallerContext';
import { siguienteId } from '../../state/tallerReducer';
import { avisar } from '../../utils/dialogos';

export default function NuevoVehiculo() {
  const router = useRouter();
  const { clientes, vehiculos, dispatch } = useTaller();
  return (
    <VehiculoForm
      propietarios={clientes.map((c) => ({ id: c.id, nombre: c.nombreCompleto, activo: c.activo }))}
      textoBoton="Guardar vehiculo LOCAL"
      alGuardar={(valor) => {
        const placa = normalizarPlaca(valor.placa);
        if (placaOcupada(placa, vehiculos)) {
          avisar('Placa duplicada', 'Ya hay un vehiculo con esa placa.');
          return;
        }
        dispatch({
          type: 'VEHICULO_CREAR',
          payload: {
            id: siguienteId(vehiculos),
            clienteId: valor.clienteId,
            placa,
            marca: valor.marca.trim(),
            modelo: valor.modelo.trim(),
            anio: Number(valor.anio),
            tipo: valor.tipo,
            kilometraje: Number(valor.kilometraje),
          },
        });
        router.replace('/vehiculos');
      }}
    />
  );
}
