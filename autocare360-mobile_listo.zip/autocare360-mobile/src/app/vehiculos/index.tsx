import { Link } from 'expo-router';
import { FlatList, Pressable, StyleSheet, Text, View } from 'react-native';
import { EmptyState } from '../../components/EmptyState';
import { VehiculoNavegable } from '../../components/VehiculoNavegable';
import { useTaller } from '../../state/TallerContext';
import { PALETTE } from '../../theme/palette';

export default function VehiculosScreen() {
  const { clientes, vehiculos } = useTaller();
  return (
    <FlatList
      data={vehiculos}
      keyExtractor={(v) => String(v.id)}
      contentContainerStyle={styles.contenido}
      ListHeaderComponent={
        <View>
          <Text style={styles.titulo}>Vehiculos LOCALES</Text>
          <Text style={styles.ayuda}>Crear, editar, eliminar y consultar el propietario (relacion 1:N).</Text>
          <Link href="/vehiculos/nuevo" asChild>
            <Pressable style={styles.boton}>
              <Text style={styles.texto}>+ Crear vehiculo</Text>
            </Pressable>
          </Link>
        </View>
      }
      renderItem={({ item }) => (
        <VehiculoNavegable
          vehiculo={item}
          nombreCliente={clientes.find((c) => c.id === item.clienteId)?.nombreCompleto ?? 'Sin propietario'}
        />
      )}
      ListEmptyComponent={<EmptyState mensaje="No hay vehiculos. Agrega uno." />}
    />
  );
}

const styles = StyleSheet.create({
  contenido: { padding: 18, paddingBottom: 40 },
  titulo: { fontSize: 23, fontWeight: '800', color: PALETTE.principal },
  ayuda: { color: PALETTE.secundario, marginTop: 10 },
  boton: { backgroundColor: PALETTE.acento, padding: 15, borderRadius: 12, marginVertical: 15 },
  texto: { color: '#fff', textAlign: 'center', fontWeight: '800' },
});
