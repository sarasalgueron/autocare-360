import { Link, useLocalSearchParams, useRouter } from 'expo-router';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { Boton } from '../../components/Boton';
import { EmptyState } from '../../components/EmptyState';
import { useTaller } from '../../state/TallerContext';
import { PALETTE } from '../../theme/palette';
import { confirmar } from '../../utils/dialogos';
import { leerIdPositivo } from '../../utils/routeParams';

export default function DetalleVehiculo() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const { clientes, vehiculos, dispatch } = useTaller();
  const vehiculo = vehiculos.find((v) => v.id === leerIdPositivo(id));

  if (!vehiculo) {
    return (
      <View style={styles.contenido}>
        <EmptyState mensaje="Vehiculo inexistente." />
      </View>
    );
  }

  async function eliminar() {
    if (!vehiculo) return;
    if (await confirmar('Eliminar vehiculo', `¿Eliminar ${vehiculo.placa}?`)) {
      dispatch({ type: 'VEHICULO_ELIMINAR', id: vehiculo.id });
      router.replace('/vehiculos');
    }
  }

  return (
    <ScrollView contentContainerStyle={styles.contenido}>
      <Text style={styles.titulo}>{vehiculo.placa}</Text>
      <Text style={styles.dato}>
        {vehiculo.marca} {vehiculo.modelo} · {vehiculo.anio} · {vehiculo.tipo}
      </Text>
      <Text style={styles.dato}>Kilometraje: {vehiculo.kilometraje.toLocaleString('es-BO')} km</Text>
      <Text style={styles.dato}>
        Propietario: {clientes.find((c) => c.id === vehiculo.clienteId)?.nombreCompleto ?? 'Sin propietario'}
      </Text>
      <Link href={{ pathname: '/vehiculos/editar/[id]', params: { id: String(vehiculo.id) } }} asChild>
        <Pressable style={styles.boton}>
          <Text style={styles.texto}>Editar vehiculo</Text>
        </Pressable>
      </Link>
      <Boton texto="Eliminar vehiculo" variante="peligro" alPresionar={() => void eliminar()} />
      <Text style={styles.aviso}>Cambios en memoria: se pierden al reiniciar la app.</Text>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  contenido: { padding: 20 },
  titulo: { fontSize: 25, fontWeight: '800', color: PALETTE.principal },
  dato: { color: PALETTE.secundario, marginTop: 13 },
  boton: { backgroundColor: PALETTE.acento, padding: 15, borderRadius: 12, marginTop: 22 },
  texto: { textAlign: 'center', color: '#fff', fontWeight: '800' },
  aviso: { marginTop: 20, color: PALETTE.secundario },
});
