import { useLocalSearchParams, useRouter } from 'expo-router';
import { Text } from 'react-native';
import { VehiculoForm } from '../../../components/VehiculoForm';
import { placaOcupada } from '../../../domain/tallerRules';
import { normalizarPlaca } from '../../../domain/validaciones';
import { useTaller } from '../../../state/TallerContext';
import { avisar } from '../../../utils/dialogos';
import { leerIdPositivo } from '../../../utils/routeParams';

export default function EditarVehiculo() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const { clientes, vehiculos, dispatch } = useTaller();
  const vehiculo = vehiculos.find((v) => v.id === leerIdPositivo(id));
  if (!vehiculo) return <Text style={{ padding: 20 }}>Vehiculo inexistente.</Text>;

  return (
    <VehiculoForm
      propietarios={clientes.map((c) => ({ id: c.id, nombre: c.nombreCompleto, activo: c.activo }))}
      textoBoton="Guardar cambios LOCALES"
      valorInicial={{
        clienteId: vehiculo.clienteId,
        placa: vehiculo.placa,
        marca: vehiculo.marca,
        modelo: vehiculo.modelo,
        anio: String(vehiculo.anio),
        tipo: vehiculo.tipo,
        kilometraje: String(vehiculo.kilometraje),
      }}
      alGuardar={(valor) => {
        const placa = normalizarPlaca(valor.placa);
        if (placaOcupada(placa, vehiculos, vehiculo.id)) {
          avisar('Conflicto', 'Esa placa ya esta asignada a otro vehiculo.');
          return;
        }
        dispatch({
          type: 'VEHICULO_EDITAR',
          payload: {
            id: vehiculo.id,
            clienteId: valor.clienteId,
            placa,
            marca: valor.marca.trim(),
            modelo: valor.modelo.trim(),
            anio: Number(valor.anio),
            tipo: valor.tipo,
            kilometraje: Number(valor.kilometraje),
          },
        });
        router.replace('/vehiculos');
      }}
    />
  );
}
