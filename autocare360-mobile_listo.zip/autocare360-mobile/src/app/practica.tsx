import { useState } from 'react';
import { ScrollView, StyleSheet, Text, View } from 'react-native';
import { ClienteCard } from '../components/ClienteCard';
import { EmptyState } from '../components/EmptyState';
import { MetricCard } from '../components/MetricCard';
import { TabSelector } from '../components/TabSelector';
import { VehiculoCard } from '../components/VehiculoCard';
import { CLIENTES, VEHICULOS } from '../data/demoData';
import type { Seccion } from '../models/taller';
import { PALETTE } from '../theme/palette';

/**
 * Guia 02 (lo que en la guia era App.tsx; desde la Guia 03 cada pantalla vive en src/app).
 * - Datos: arreglos de demoData.ts (NO vienen de la API ni de PostgreSQL).
 * - Estado: la seccion elegida y el cliente seleccionado viven AQUI, en el padre.
 * - Props hacia abajo: TabSelector, ClienteCard y VehiculoCard solo reciben datos.
 * - Callbacks hacia arriba: alCambiar -> setSeccion, alSeleccionar -> setClienteId.
 * - Relacion 1:N: los vehiculos del cliente se obtienen con filter por clienteId.
 */
export default function PracticaGuia02() {
  const [seccion, setSeccion] = useState<Seccion>('clientes');
  const [clienteId, setClienteId] = useState<number | null>(null);

  // Datos DERIVADOS: se calculan en cada render a partir de los arreglos (no se guardan en useState).
  const totalClientes = CLIENTES.length; // 4
  const totalVehiculos = VEHICULOS.length; // 5
  const clienteSeleccionado = CLIENTES.find((c) => c.id === clienteId) ?? null;
  const vehiculosDelCliente = VEHICULOS.filter((v) => v.clienteId === clienteId);
  const nombreDe = (id: number) => CLIENTES.find((c) => c.id === id)?.nombreCompleto ?? `Cliente #${id}`;

  return (
    <ScrollView contentContainerStyle={styles.contenido}>
      <Text style={styles.titulo}>Practica Guia 02</Text>
      <Text style={styles.ayuda}>Componentes, props, estado y estilos con datos locales de demostracion.</Text>

      <View style={styles.metricas}>
        <MetricCard etiqueta="Clientes" valor={totalClientes} />
        <MetricCard etiqueta="Vehiculos" valor={totalVehiculos} />
      </View>

      <TabSelector actual={seccion} alCambiar={setSeccion} />

      {seccion === 'clientes' ? (
        <View>
          <Text style={styles.subtitulo}>Toca un cliente para ver sus vehiculos</Text>
          {CLIENTES.map((cliente) => {
            const cantidad = VEHICULOS.filter((v) => v.clienteId === cliente.id).length;
            return (
              <ClienteCard
                key={cliente.id}
                nombre={cliente.nombreCompleto}
                documento={cliente.documento}
                activo={cliente.activo}
                detalle={`${cantidad} vehiculo(s)${cliente.id === clienteId ? ' · SELECCIONADO' : ''}`}
                alSeleccionar={() => setClienteId(cliente.id)}
              />
            );
          })}

          {/* Render condicional: sin seleccion no se muestra el panel de detalle. */}
          {clienteSeleccionado && (
            <View style={styles.panel}>
              <Text style={styles.subtitulo}>Vehiculos de {clienteSeleccionado.nombreCompleto}</Text>
              {vehiculosDelCliente.length === 0 ? (
                <EmptyState mensaje="Este cliente no tiene vehiculos registrados." />
              ) : (
                vehiculosDelCliente.map((v) => (
                  <VehiculoCard
                    key={v.id}
                    placa={v.placa}
                    marca={v.marca}
                    modelo={v.modelo}
                    anio={v.anio}
                    kilometraje={v.kilometraje}
                    nombreCliente={clienteSeleccionado.nombreCompleto}
                  />
                ))
              )}
            </View>
          )}
        </View>
      ) : (
        <View>
          <Text style={styles.subtitulo}>Todos los vehiculos</Text>
          {VEHICULOS.map((v) => (
            <VehiculoCard
              key={v.id}
              placa={v.placa}
              marca={v.marca}
              modelo={v.modelo}
              anio={v.anio}
              kilometraje={v.kilometraje}
              nombreCliente={nombreDe(v.clienteId)}
            />
          ))}
        </View>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  contenido: { padding: 20, paddingBottom: 48, backgroundColor: PALETTE.fondo },
  titulo: { fontSize: 25, fontWeight: '800', color: PALETTE.principal },
  ayuda: { color: PALETTE.secundario, lineHeight: 22, marginTop: 6 },
  metricas: { flexDirection: 'row', gap: 10, marginTop: 14 },
  subtitulo: { fontSize: 16, fontWeight: '800', color: PALETTE.principal, marginTop: 18, marginBottom: 10 },
  panel: { marginTop: 6 },
});
