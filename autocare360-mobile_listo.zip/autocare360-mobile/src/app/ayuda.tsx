import { Link } from 'expo-router';
import { Pressable, ScrollView, StyleSheet, Text } from 'react-native';
import { ReturnButton } from '../components/ReturnButton';
import { PALETTE } from '../theme/palette';

/** Ruta /ayuda: que se practica y pruebas de errores controlados (Guia 03). */
export default function AyudaScreen() {
  return (
    <ScrollView contentContainerStyle={styles.contenido}>
      <ReturnButton destinoSiNoHayHistorial="/" />
      <Text style={styles.titulo}>¿Que estamos practicando?</Text>
      <Text style={styles.parrafo}>
        Una ruta representa una pantalla. La parte LOCAL usa datos inventados dentro del telefono; la parte del
        TALLER (con sesion) consulta Spring Boot y PostgreSQL.
      </Text>
      <Text style={styles.subtitulo}>Laboratorio: identificadores invalidos</Text>
      <Text style={styles.parrafo}>La app debe mostrar un mensaje y no cerrarse.</Text>
      <Link href={{ pathname: '/clientes/[id]', params: { id: '999' } }} asChild>
        <Pressable style={styles.accion} accessibilityRole="link">
          <Text style={styles.accionTexto}>Probar cliente 999</Text>
        </Pressable>
      </Link>
      <Link href={{ pathname: '/vehiculos/[id]', params: { id: 'abc' } }} asChild>
        <Pressable style={styles.accion} accessibilityRole="link">
          <Text style={styles.accionTexto}>Probar vehiculo con ID invalido</Text>
        </Pressable>
      </Link>
      <Text style={styles.subtitulo}>Conexion con el backend</Text>
      <Text style={styles.parrafo}>
        En el emulador Android la PC se llama 10.0.2.2. En un telefono fisico usa la IP de tu PC (misma Wi-Fi) en el
        archivo .env: EXPO_PUBLIC_API_URL=http://192.168.x.x:8080/api
      </Text>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  contenido: { padding: 18, paddingBottom: 40 },
  titulo: { marginTop: 8, fontSize: 23, fontWeight: '800', color: PALETTE.principal },
  subtitulo: { marginTop: 25, fontSize: 18, fontWeight: '800', color: PALETTE.principal },
  parrafo: { marginTop: 12, lineHeight: 23, color: PALETTE.secundario },
  accion: { backgroundColor: PALETTE.acentoClaro, borderRadius: 12, padding: 17, marginTop: 12 },
  accionTexto: { textAlign: 'center', fontWeight: '700', color: PALETTE.principal },
});
