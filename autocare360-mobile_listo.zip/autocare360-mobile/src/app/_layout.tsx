import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { AuthProvider } from '../state/AuthContext';
import { TallerProvider } from '../state/TallerContext';
import { PALETTE } from '../theme/palette';

/**
 * Layout raiz (Guia 03): define el Stack de navegacion y los titulos.
 * AuthProvider (sesion) y TallerProvider (datos locales) envuelven a TODAS las pantallas.
 */
export default function RootLayout() {
  return (
    <AuthProvider>
      <TallerProvider>
        <StatusBar style="light" />
        <Stack
          screenOptions={{
            headerStyle: { backgroundColor: PALETTE.principal },
            headerTintColor: PALETTE.superficie,
            contentStyle: { backgroundColor: PALETTE.fondo },
          }}
        >
          <Stack.Screen name="index" options={{ title: 'AutoCare 360' }} />
          <Stack.Screen name="clientes/index" options={{ title: 'Clientes (local)' }} />
          <Stack.Screen name="clientes/nuevo" options={{ title: 'Nuevo cliente' }} />
          <Stack.Screen name="clientes/editar/[id]" options={{ title: 'Editar cliente' }} />
          <Stack.Screen name="clientes/[id]" options={{ title: 'Detalle cliente' }} />
          <Stack.Screen name="vehiculos/index" options={{ title: 'Vehiculos (local)' }} />
          <Stack.Screen name="vehiculos/nuevo" options={{ title: 'Nuevo vehiculo' }} />
          <Stack.Screen name="vehiculos/editar/[id]" options={{ title: 'Editar vehiculo' }} />
          <Stack.Screen name="vehiculos/[id]" options={{ title: 'Detalle vehiculo' }} />
          <Stack.Screen name="diagnostico" options={{ title: 'Diagnostico API' }} />
          <Stack.Screen name="login" options={{ title: 'Iniciar sesion' }} />
          <Stack.Screen name="remoto" options={{ headerShown: false }} />
          <Stack.Screen name="ayuda" options={{ title: 'Ayuda' }} />
          <Stack.Screen name="practica" options={{ title: 'Practica Guia 02' }} />
        </Stack>
      </TallerProvider>
    </AuthProvider>
  );
}
