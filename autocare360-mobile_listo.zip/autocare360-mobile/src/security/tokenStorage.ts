import * as SecureStore from 'expo-secure-store';
import { Platform } from 'react-native';

const TOKEN_KEY = 'autocare_access_token';

/**
 * Guia 11: el token se guarda CIFRADO con SecureStore (Keystore de Android).
 * Nunca guardamos la contrasena en el telefono, solo el token.
 *
 * SecureStore no existe en el navegador. Solo cuando se prueba con "npx expo start --web"
 * usamos sessionStorage (se borra al cerrar la pestana). En Android SIEMPRE se usa SecureStore.
 */
const esWeb = Platform.OS === 'web';

/** Quien quiera enterarse de que el token se borro (AuthContext) se suscribe aqui. */
type Oyente = () => void;
const oyentes = new Set<Oyente>();

export const tokenStorage = {
  leer: async (): Promise<string | null> =>
    esWeb ? globalThis.sessionStorage?.getItem(TOKEN_KEY) ?? null : SecureStore.getItemAsync(TOKEN_KEY),
  guardar: async (token: string): Promise<void> =>
    esWeb ? globalThis.sessionStorage?.setItem(TOKEN_KEY, token) : SecureStore.setItemAsync(TOKEN_KEY, token),
  borrar: async (): Promise<void> =>
    esWeb ? globalThis.sessionStorage?.removeItem(TOKEN_KEY) : SecureStore.deleteItemAsync(TOKEN_KEY),
  /**
   * El backend respondio 401 a una peticion que SI llevaba token: el token vencio (60 min) o es falso.
   * Se borra y se avisa a AuthContext para que /remoto redirija a /login (en vez de quedar trabado).
   */
  invalidar: async (): Promise<void> => {
    await tokenStorage.borrar();
    oyentes.forEach((oyente) => oyente());
  },
  alInvalidar: (oyente: Oyente): (() => void) => {
    oyentes.add(oyente);
    return () => oyentes.delete(oyente);
  },
};
