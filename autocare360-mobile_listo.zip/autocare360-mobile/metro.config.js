// Configuracion de Metro (empaquetador de Expo).
// expo-sqlite (Guia 12) en la version WEB usa un archivo .wasm: hay que registrarlo como asset
// y servir la pagina con las cabeceras COOP/COEP que exige SharedArrayBuffer.
// En Android no cambia nada; solo permite que `npm run web` tambien compile.
const { getDefaultConfig } = require('expo/metro-config');

const config = getDefaultConfig(__dirname);

config.resolver.assetExts.push('wasm');

config.server.enhanceMiddleware = (middleware) => (req, res, next) => {
  res.setHeader('Cross-Origin-Embedder-Policy', 'credentialless');
  res.setHeader('Cross-Origin-Opener-Policy', 'same-origin');
  middleware(req, res, next);
};

module.exports = config;
