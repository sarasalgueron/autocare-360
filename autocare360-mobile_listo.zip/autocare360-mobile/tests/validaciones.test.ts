import { describe, expect, it } from 'vitest';
import { normalizarPlaca, validarCliente, validarVehiculo, type VehiculoFormValue } from '../src/domain/validaciones';
import { leerIdPositivo } from '../src/utils/routeParams';

const vehiculoValido: VehiculoFormValue = {
  clienteId: 1,
  placa: '4567-abc',
  marca: 'Toyota',
  modelo: 'Corolla',
  anio: '2022',
  tipo: 'AUTO',
  kilometraje: '35000',
};

describe('validarVehiculo', () => {
  it('quita espacios y convierte la placa a mayusculas', () => expect(normalizarPlaca(' 4567-abc ')).toBe('4567-ABC'));
  it('acepta un formulario correcto', () => expect(validarVehiculo(vehiculoValido, [1])).toEqual({}));
  it('rechaza un propietario que no esta en la lista', () =>
    expect(validarVehiculo({ ...vehiculoValido, clienteId: 999 }, [1]).clienteId).toBeTruthy());
  it('rechaza placa con simbolos', () => expect(validarVehiculo({ ...vehiculoValido, placa: '45#7 AB' }, [1]).placa).toBeTruthy());
  it('rechaza anio fuera de rango y kilometraje negativo', () => {
    const errores = validarVehiculo({ ...vehiculoValido, anio: '1800', kilometraje: '-5' }, [1]);
    expect(errores.anio).toBeTruthy();
    expect(errores.kilometraje).toBeTruthy();
  });
});

describe('validarCliente', () => {
  const base = { documento: '7845123', nombreCompleto: 'Ana Rojas', email: '', telefono: '', activo: true };
  it('acepta cliente sin correo ni telefono (son opcionales)', () => expect(validarCliente(base)).toEqual({}));
  it('rechaza documento corto', () => expect(validarCliente({ ...base, documento: '123' }).documento).toBeTruthy());
  it('rechaza correo invalido', () => expect(validarCliente({ ...base, email: 'no-es-correo' }).email).toBeTruthy());
});

describe('leerIdPositivo', () => {
  it('acepta "7"', () => expect(leerIdPositivo('7')).toBe(7));
  it('rechaza "abc", "0", "-1" y arreglos', () => {
    expect(leerIdPositivo('abc')).toBeNull();
    expect(leerIdPositivo('0')).toBeNull();
    expect(leerIdPositivo('-1')).toBeNull();
    expect(leerIdPositivo(['1', '2'])).toBeNull();
  });
});
