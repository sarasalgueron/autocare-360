import { describe, expect, it } from 'vitest';
import { accionesMovil, esOrdenActiva } from '../src/domain/estadoOrden';

describe('Acciones moviles sobre la orden (RF-17)', () => {
  it('en ESPERA_APROBACION el cliente puede aprobar o rechazar', () => {
    const acciones = accionesMovil('ESPERA_APROBACION', ['EN_TRABAJO', 'DIAGNOSTICO', 'CANCELADA']);
    expect(acciones.map((a) => a.tipo)).toEqual(['aprobar', 'rechazar']);
    expect(acciones[0].destino).toBe('EN_TRABAJO');
    expect(acciones[1].destino).toBe('DIAGNOSTICO');
  });

  it('el tecnico registra avance, pero no cancela ni entrega desde el movil', () => {
    const acciones = accionesMovil('EN_TRABAJO', ['LISTA_ENTREGA', 'CANCELADA']);
    expect(acciones).toHaveLength(1);
    expect(acciones[0]).toMatchObject({ destino: 'LISTA_ENTREGA', tipo: 'avance' });
    expect(accionesMovil('LISTA_ENTREGA', ['ENTREGADA'])).toEqual([]);
  });

  it('solo ofrece lo que el backend permite', () => {
    expect(accionesMovil('ESPERA_APROBACION', [])).toEqual([]);
  });

  it('ENTREGADA y CANCELADA no son ordenes activas', () => {
    expect(esOrdenActiva('EN_TRABAJO')).toBe(true);
    expect(esOrdenActiva('ENTREGADA')).toBe(false);
    expect(esOrdenActiva('CANCELADA')).toBe(false);
  });
});
