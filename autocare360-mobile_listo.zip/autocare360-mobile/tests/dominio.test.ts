import { describe, expect, it } from 'vitest';
import { CLIENTES, VEHICULOS } from '../src/data/demoData';
import { clienteActivo, clienteExiste, idsPropietariosValidos, placaOcupada, puedeEliminarCliente, vehiculosDe } from '../src/domain/tallerRules';
import { initialTallerState, siguienteId, tallerReducer } from '../src/state/tallerReducer';

describe('Relacion Cliente (1) - Vehiculo (N)', () => {
  it('Ana tiene dos vehiculos', () => expect(vehiculosDe(1, VEHICULOS)).toHaveLength(2));
  it('Diego no tiene vehiculos', () => expect(vehiculosDe(4, VEHICULOS)).toHaveLength(0));
  it('no se elimina a Ana porque tiene vehiculos', () => expect(puedeEliminarCliente(1, VEHICULOS)).toBe(false));
  it('si se puede eliminar a Diego', () => expect(puedeEliminarCliente(4, VEHICULOS)).toBe(true));
  it('detecta placa repetida', () => expect(placaOcupada('4567-ABC', VEHICULOS)).toBe(true));
  it('al editar, la propia placa no cuenta como repetida', () => expect(placaOcupada('4567-ABC', VEHICULOS, 101)).toBe(false));
  it('solo acepta clientes existentes', () => expect(clienteExiste(88, CLIENTES)).toBe(false));
  it('RN-01: Lucia esta inactiva', () => expect(clienteActivo(3, CLIENTES)).toBe(false));
  it('propietarios validos: activos + el actual al editar', () => {
    expect(idsPropietariosValidos(CLIENTES)).toEqual([1, 2, 4]);
    expect(idsPropietariosValidos(CLIENTES, 3)).toEqual([1, 2, 3, 4]);
  });
  it('genera el siguiente id local', () => expect(siguienteId(CLIENTES)).toBe(5));
});

describe('tallerReducer', () => {
  it('no permite eliminar un cliente con vehiculos', () => {
    const estado = tallerReducer(initialTallerState, { type: 'CLIENTE_ELIMINAR', id: 1 });
    expect(estado.clientes).toHaveLength(4);
  });

  it('si elimina un cliente sin vehiculos', () => {
    const estado = tallerReducer(initialTallerState, { type: 'CLIENTE_ELIMINAR', id: 4 });
    expect(estado.clientes).toHaveLength(3);
  });

  it('RN-01: no crea un vehiculo para un cliente inactivo', () => {
    const estado = tallerReducer(initialTallerState, {
      type: 'VEHICULO_CREAR',
      payload: { id: 200, clienteId: 3, placa: '9999-ZZZ', marca: 'Ford', modelo: 'Ka', anio: 2018, tipo: 'AUTO', kilometraje: 0 },
    });
    expect(estado.vehiculos).toHaveLength(5);
  });

  it('no modifica el estado original (inmutabilidad)', () => {
    const antes = initialTallerState.vehiculos;
    tallerReducer(initialTallerState, { type: 'VEHICULO_ELIMINAR', id: 101 });
    expect(initialTallerState.vehiculos).toBe(antes);
    expect(initialTallerState.vehiculos).toHaveLength(5);
  });
});
