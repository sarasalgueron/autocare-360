import { describe, expect, it } from 'vitest';
import { CLIENTES, VEHICULOS } from '../src/data/demoData';

// Guia 02 (Anexo B): contadores 4 y 5 calculados desde arreglos y relacion 1:N por clienteId.
describe('Guia 02 - datos de demostracion', () => {
  it('tiene 4 clientes y 5 vehiculos', () => {
    expect(CLIENTES.length).toBe(4);
    expect(VEHICULOS.length).toBe(5);
  });

  it('reparte los vehiculos 2, 1, 2 y 0 (el ultimo cliente muestra estado vacio)', () => {
    const porCliente = CLIENTES.map((c) => VEHICULOS.filter((v) => v.clienteId === c.id).length);
    expect(porCliente).toEqual([2, 1, 2, 0]);
  });

  it('cada vehiculo apunta a un cliente existente', () => {
    const ids = new Set(CLIENTES.map((c) => c.id));
    expect(VEHICULOS.every((v) => ids.has(v.clienteId))).toBe(true);
  });
});
