package com.autocare.Cliente.infrastructure.adapter.in.web.dto;

public record ClienteResponse(
        Long id,
        String documento,
        String nombreCompleto,
        String email,
        String telefono
) {}
