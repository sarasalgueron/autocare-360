package com.autocare.Cliente.infrastructure.adapter.in.web.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import jakarta.validation.constraints.Email;

public record CrearClienteRequest(
        @NotBlank(message = "El documento es obligatorio")
        @Size(max = 30, message = "El documento no puede superar 30 caracteres")
        String documento,

        @NotBlank(message = "El nombre completo es obligatorio")
        @Size(max = 180, message = "El nombre no puede superar 180 caracteres")
        String nombreCompleto,

        @NotBlank(message = "El email es obligatorio")
        @Email(message = "El email no tiene un formato válido")
        String email,

        @Pattern(regexp = "^[0-9+\\- ]{7,20}$", message = "El teléfono no tiene un formato válido")
        String telefono

)
{

}

