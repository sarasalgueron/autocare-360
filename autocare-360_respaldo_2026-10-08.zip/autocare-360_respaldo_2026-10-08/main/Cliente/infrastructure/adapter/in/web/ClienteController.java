package com.autocare.Cliente.infrastructure.adapter.in.web;

import com.autocare.Cliente.application.ClienteService;
import com.autocare.Cliente.Domain.Cliente;
import com.autocare.Cliente.infrastructure.adapter.in.web.dto.ClienteResponse;
import com.autocare.Cliente.infrastructure.adapter.in.web.dto.CrearClienteRequest;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/clientes")
public class ClienteController {

    private final ClienteService clienteService;

    public ClienteController(ClienteService clienteService) {
        this.clienteService = clienteService;
    }

    @PostMapping
    public ResponseEntity<ClienteResponse> crear(
            @Valid @RequestBody CrearClienteRequest request) {

        Cliente creado = clienteService.registrar(
                request.documento(),
                request.nombreCompleto(),
                request.email(),
                request.telefono()
        );

        return ResponseEntity.status(HttpStatus.CREATED)
                .body(toResponse(creado));
    }

    @GetMapping
    public List<ClienteResponse> listar(
            @RequestParam(required = false) String nombre) {

        return clienteService.listar().stream()
                .filter(c -> nombre == null ||
                        c.getNombreCompleto().toLowerCase().contains(nombre.toLowerCase()))
                .map(this::toResponse)
                .toList();
    }

    @GetMapping("/{id}")
    public ResponseEntity<ClienteResponse> buscarPorId(@PathVariable Long id) {
        return clienteService.buscarPorId(id)
                .map(cliente -> ResponseEntity.ok(toResponse(cliente)))
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    private ClienteResponse toResponse(Cliente cliente) {
        return new ClienteResponse(
                cliente.getId(),
                cliente.getDocumento(),
                cliente.getNombreCompleto(),
                cliente.getEmail(),
                cliente.getTelefono()
        );
    }
}
